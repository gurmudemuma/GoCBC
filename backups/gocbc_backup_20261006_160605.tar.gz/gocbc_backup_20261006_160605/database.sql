--
-- PostgreSQL database dump
--

\restrict YmSEDghiqxaZTntYMF1d9GsRskgEBOY9MMHhPjQbQdYQIDhXgaxwcQnznbVJ7zx

-- Dumped from database version 15.19
-- Dumped by pg_dump version 15.19

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auto_resolve_issues(); Type: FUNCTION; Schema: public; Owner: cecbs
--

CREATE FUNCTION public.auto_resolve_issues() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- Resolve payment overdue issues when payment received
  IF NEW.payment_received = TRUE AND OLD.payment_received = FALSE THEN
    UPDATE post_delivery_issues
    SET resolved = TRUE, resolved_at = CURRENT_TIMESTAMP
    WHERE shipment_id = NEW.shipment_id AND issue_type = 'PAYMENT_OVERDUE';
  END IF;
  
  -- Resolve forex delay issues when forex repatriated
  IF NEW.forex_repatriated = TRUE AND OLD.forex_repatriated = FALSE THEN
    UPDATE post_delivery_issues
    SET resolved = TRUE, resolved_at = CURRENT_TIMESTAMP
    WHERE shipment_id = NEW.shipment_id AND issue_type = 'FOREX_DELAYED';
  END IF;
  
  -- Resolve LC issues when LC settled
  IF NEW.lc_settled = TRUE AND OLD.lc_settled = FALSE THEN
    UPDATE post_delivery_issues
    SET resolved = TRUE, resolved_at = CURRENT_TIMESTAMP
    WHERE shipment_id = NEW.shipment_id AND issue_type = 'LC_ISSUE';
  END IF;
  
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.auto_resolve_issues() OWNER TO cecbs;

--
-- Name: check_approval_complete(character varying); Type: FUNCTION; Schema: public; Owner: cecbs
--

CREATE FUNCTION public.check_approval_complete(doc_id character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    workflow_record RECORD;
BEGIN
    SELECT * INTO workflow_record 
    FROM approval_workflow_state 
    WHERE document_id = doc_id;
    
    IF workflow_record IS NULL THEN
        RETURN true; -- No workflow, consider approved
    END IF;
    
    RETURN workflow_record.current_approvals >= workflow_record.required_approvals;
END;
$$;


ALTER FUNCTION public.check_approval_complete(doc_id character varying) OWNER TO cecbs;

--
-- Name: cleanup_old_audit_logs(); Type: FUNCTION; Schema: public; Owner: cecbs
--

CREATE FUNCTION public.cleanup_old_audit_logs() RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
  deleted_count INTEGER;
BEGIN
  DELETE FROM audit_log 
  WHERE created_at < NOW() - INTERVAL '90 days';
  
  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  RETURN deleted_count;
END;
$$;


ALTER FUNCTION public.cleanup_old_audit_logs() OWNER TO cecbs;

--
-- Name: FUNCTION cleanup_old_audit_logs(); Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON FUNCTION public.cleanup_old_audit_logs() IS 'Removes audit logs older than 90 days';


--
-- Name: update_approval_workflow(); Type: FUNCTION; Schema: public; Owner: cecbs
--

CREATE FUNCTION public.update_approval_workflow() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    workflow_id INTEGER;
    required_count INTEGER;
BEGIN
    -- Only process approval signatures
    IF NEW.signature_type = 'approve' AND NEW.approval_status = 'approved' THEN
        -- Check if workflow exists
        SELECT id, required_approvals INTO workflow_id, required_count
        FROM approval_workflow_state
        WHERE document_id = NEW.document_id;
        
        IF workflow_id IS NOT NULL THEN
            -- Update workflow state
            UPDATE approval_workflow_state
            SET 
                current_approvals = current_approvals + 1,
                approved_by = array_append(approved_by, NEW.signed_by),
                approval_status = CASE 
                    WHEN current_approvals + 1 >= required_approvals THEN 'approved'
                    ELSE 'in_progress'
                END,
                completed_at = CASE 
                    WHEN current_approvals + 1 >= required_approvals THEN NOW()
                    ELSE NULL
                END,
                updated_at = NOW()
            WHERE id = workflow_id;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_approval_workflow() OWNER TO cecbs;

--
-- Name: update_lc_discrepancy_timestamp(); Type: FUNCTION; Schema: public; Owner: cecbs
--

CREATE FUNCTION public.update_lc_discrepancy_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_lc_discrepancy_timestamp() OWNER TO cecbs;

--
-- Name: update_post_delivery_completion(); Type: FUNCTION; Schema: public; Owner: cecbs
--

CREATE FUNCTION public.update_post_delivery_completion() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  total_steps INTEGER;
  completed_steps INTEGER := 0;
BEGIN
  -- Determine total steps (5 if LC used, 4 if not)
  IF NEW.lc_used THEN
    total_steps := 5;
  ELSE
    total_steps := 4;
  END IF;
  
  -- Count completed steps
  IF NEW.payment_received THEN
    completed_steps := completed_steps + 1;
  END IF;
  
  IF NEW.forex_repatriated THEN
    completed_steps := completed_steps + 1;
  END IF;
  
  IF NOT NEW.lc_used OR NEW.lc_settled THEN
    completed_steps := completed_steps + 1;
  END IF;
  
  IF NEW.ecta_audit_completed THEN
    completed_steps := completed_steps + 1;
  END IF;
  
  IF NEW.contract_closed THEN
    completed_steps := completed_steps + 1;
  END IF;
  
  -- Update completion percentage
  NEW.completion_percentage := ROUND((completed_steps::DECIMAL / total_steps) * 100);
  
  -- Update overall status
  IF NEW.contract_closed THEN
    NEW.overall_status := 'COMPLETED';
  ELSIF completed_steps > 0 THEN
    NEW.overall_status := 'IN_PROGRESS';
  END IF;
  
  NEW.updated_at := CURRENT_TIMESTAMP;
  
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_post_delivery_completion() OWNER TO cecbs;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _schema_migrations; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public._schema_migrations (
    id integer NOT NULL,
    migration_name character varying(255) NOT NULL,
    applied_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public._schema_migrations OWNER TO cecbs;

--
-- Name: _schema_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public._schema_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public._schema_migrations_id_seq OWNER TO cecbs;

--
-- Name: _schema_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public._schema_migrations_id_seq OWNED BY public._schema_migrations.id;


--
-- Name: approval_requirements; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.approval_requirements (
    id integer NOT NULL,
    document_type character varying(100) NOT NULL,
    entity_type character varying(50) NOT NULL,
    min_approvers integer DEFAULT 1 NOT NULL,
    required_roles text[],
    approval_order character varying(50) DEFAULT 'parallel'::character varying,
    description text,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.approval_requirements OWNER TO cecbs;

--
-- Name: approval_requirements_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.approval_requirements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.approval_requirements_id_seq OWNER TO cecbs;

--
-- Name: approval_requirements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.approval_requirements_id_seq OWNED BY public.approval_requirements.id;


--
-- Name: approval_workflow_state; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.approval_workflow_state (
    id integer NOT NULL,
    entity_type character varying(100),
    entity_id character varying(100),
    current_state character varying(50),
    required_approvals integer,
    received_approvals integer DEFAULT 0,
    status character varying(50) DEFAULT 'pending'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    document_id character varying(255),
    document_type character varying(100),
    current_approvals integer DEFAULT 0,
    approval_status character varying(50) DEFAULT 'pending'::character varying,
    approved_by text[],
    rejected_by character varying(255),
    rejection_reason text,
    completed_at timestamp without time zone,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.approval_workflow_state OWNER TO cecbs;

--
-- Name: approval_workflow_state_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.approval_workflow_state_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.approval_workflow_state_id_seq OWNER TO cecbs;

--
-- Name: approval_workflow_state_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.approval_workflow_state_id_seq OWNED BY public.approval_workflow_state.id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    entity_type character varying(100),
    entity_id character varying(100),
    action character varying(100),
    user_id integer,
    details jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    username character varying(100),
    ip_address character varying(45),
    user_agent text
);


ALTER TABLE public.audit_log OWNER TO cecbs;

--
-- Name: TABLE audit_log; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.audit_log IS 'API-level audit log capturing all user actions';


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_log_id_seq OWNER TO cecbs;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    action character varying(255),
    entity_type character varying(100),
    entity_id character varying(100),
    user_id integer,
    changes jsonb,
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    event_type character varying(100),
    event_category character varying(50),
    severity character varying(20) DEFAULT 'INFO'::character varying,
    username character varying(255),
    user_role character varying(50),
    organization character varying(100),
    description text,
    resource_type character varying(100),
    resource_id character varying(255),
    ip_address inet,
    user_agent text,
    endpoint character varying(255),
    http_method character varying(10),
    http_status integer,
    old_value jsonb,
    new_value jsonb,
    blockchain_tx_id character varying(255),
    blockchain_block_number bigint,
    blockchain_timestamp timestamp without time zone,
    metadata jsonb,
    tags text[],
    CONSTRAINT audit_logs_valid_category CHECK (((event_category)::text = ANY ((ARRAY['AUTH'::character varying, 'BLOCKCHAIN'::character varying, 'DATABASE'::character varying, 'API'::character varying, 'SECURITY'::character varying, 'SYSTEM'::character varying])::text[]))),
    CONSTRAINT audit_logs_valid_severity CHECK (((severity)::text = ANY ((ARRAY['DEBUG'::character varying, 'INFO'::character varying, 'WARN'::character varying, 'ERROR'::character varying, 'CRITICAL'::character varying])::text[])))
);


ALTER TABLE public.audit_logs OWNER TO cecbs;

--
-- Name: TABLE audit_logs; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.audit_logs IS 'Comprehensive system audit trail';


--
-- Name: COLUMN audit_logs.event_type; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.audit_logs.event_type IS 'Type of event (LOGIN, CREATE_CONTRACT, etc.)';


--
-- Name: COLUMN audit_logs.event_category; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.audit_logs.event_category IS 'Category: AUTH, BLOCKCHAIN, DATABASE, API, SECURITY, SYSTEM';


--
-- Name: COLUMN audit_logs.severity; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.audit_logs.severity IS 'Log severity level';


--
-- Name: COLUMN audit_logs.blockchain_tx_id; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.audit_logs.blockchain_tx_id IS 'Associated Fabric transaction ID if applicable';


--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_logs_id_seq OWNER TO cecbs;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: audit_trail; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.audit_trail (
    id integer NOT NULL,
    entity_type character varying(100),
    entity_id character varying(100),
    action character varying(100),
    user_id integer,
    old_value jsonb,
    new_value jsonb,
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    ip_address character varying(45),
    performed_by_org character varying(100),
    performed_by character varying(255),
    organization character varying(100),
    changes jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    blockchain_tx_id character varying(255),
    reason text,
    metadata jsonb DEFAULT '{}'::jsonb
);


ALTER TABLE public.audit_trail OWNER TO cecbs;

--
-- Name: TABLE audit_trail; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.audit_trail IS 'Complete audit trail of all system changes';


--
-- Name: COLUMN audit_trail.entity_type; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.audit_trail.entity_type IS 'Type of entity (CONTRACT, EXPORTER, LC, PAYMENT, etc.)';


--
-- Name: COLUMN audit_trail.entity_id; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.audit_trail.entity_id IS 'Unique identifier of the entity';


--
-- Name: COLUMN audit_trail.action; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.audit_trail.action IS 'Action performed (CREATE, UPDATE, APPROVE, REJECT, etc.)';


--
-- Name: COLUMN audit_trail.old_value; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.audit_trail.old_value IS 'Previous value/state before the action';


--
-- Name: COLUMN audit_trail.new_value; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.audit_trail.new_value IS 'New value/state after the action';


--
-- Name: COLUMN audit_trail.ip_address; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.audit_trail.ip_address IS 'IP address of the user who performed the action';


--
-- Name: COLUMN audit_trail.performed_by_org; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.audit_trail.performed_by_org IS 'Organization of the user (ECTAMSP, BANKSMSP, etc.)';


--
-- Name: COLUMN audit_trail.performed_by; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.audit_trail.performed_by IS 'Username/ID of user who performed the action';


--
-- Name: COLUMN audit_trail.blockchain_tx_id; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.audit_trail.blockchain_tx_id IS 'Blockchain transaction ID if applicable';


--
-- Name: COLUMN audit_trail.reason; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.audit_trail.reason IS 'Reason or notes for the action';


--
-- Name: COLUMN audit_trail.metadata; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.audit_trail.metadata IS 'Additional contextual information as JSON';


--
-- Name: audit_trail_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.audit_trail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_trail_id_seq OWNER TO cecbs;

--
-- Name: audit_trail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.audit_trail_id_seq OWNED BY public.audit_trail.id;


--
-- Name: blockchain_contracts; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.blockchain_contracts (
    contract_id character varying(100) NOT NULL,
    exporter_id character varying(100),
    buyer_id character varying(100),
    contract_type character varying(50),
    quantity numeric(10,2),
    price_per_kg numeric(10,2),
    total_value numeric(15,2),
    payment_terms character varying(100),
    status character varying(50),
    created_at timestamp without time zone,
    synced_from character varying(20),
    synced_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    raw_data jsonb
);


ALTER TABLE public.blockchain_contracts OWNER TO cecbs;

--
-- Name: TABLE blockchain_contracts; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.blockchain_contracts IS 'Synced copy of contracts from blockchain CouchDB state database';


--
-- Name: blockchain_customs; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.blockchain_customs (
    clearance_id character varying(100) NOT NULL,
    shipment_id character varying(100),
    declaration_number character varying(100),
    clearance_status character varying(50),
    duty_paid numeric(15,2),
    clearance_date timestamp without time zone,
    exit_point character varying(100),
    created_at timestamp without time zone,
    synced_from character varying(20),
    synced_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    raw_data jsonb
);


ALTER TABLE public.blockchain_customs OWNER TO cecbs;

--
-- Name: TABLE blockchain_customs; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.blockchain_customs IS 'Synced copy of customs clearances from blockchain CouchDB state database';


--
-- Name: blockchain_documents; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.blockchain_documents (
    document_id character varying(100) NOT NULL,
    shipment_id character varying(100),
    document_type character varying(50),
    issuer character varying(100),
    status character varying(50),
    ipfs_hash character varying(255),
    file_path text,
    verified boolean,
    verification_date timestamp without time zone,
    created_at timestamp without time zone,
    synced_from character varying(20),
    synced_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    raw_data jsonb
);


ALTER TABLE public.blockchain_documents OWNER TO cecbs;

--
-- Name: TABLE blockchain_documents; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.blockchain_documents IS 'Synced copy of documents from blockchain CouchDB state database';


--
-- Name: blockchain_payments; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.blockchain_payments (
    payment_id character varying(100) NOT NULL,
    shipment_id character varying(100),
    lc_number character varying(100),
    amount numeric(15,2),
    currency character varying(10),
    status character varying(50),
    payment_date timestamp without time zone,
    bank_reference character varying(100),
    created_at timestamp without time zone,
    synced_from character varying(20),
    synced_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    raw_data jsonb
);


ALTER TABLE public.blockchain_payments OWNER TO cecbs;

--
-- Name: TABLE blockchain_payments; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.blockchain_payments IS 'Synced copy of payments from blockchain CouchDB state database';


--
-- Name: blockchain_shipments; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.blockchain_shipments (
    shipment_id character varying(100) NOT NULL,
    contract_id character varying(100),
    exporter_id character varying(100),
    buyer_id character varying(100),
    origin character varying(100),
    quantity numeric(10,2),
    grade character varying(50),
    ico_number character varying(100),
    ecx_lot_number character varying(100),
    ecx_lots text[],
    documents text[],
    status character varying(50),
    channel character varying(50),
    forex_rate numeric(10,4),
    value_usd numeric(15,2),
    eudr_compliant boolean,
    packaging_type character varying(50),
    bag_weight numeric(10,2),
    total_bags integer,
    net_weight numeric(10,2),
    gross_weight numeric(10,2),
    insurance_policy character varying(100),
    insurance_company character varying(100),
    insurance_amount numeric(15,2),
    transport_mode character varying(20),
    shipping_line character varying(255),
    bill_of_lading_no character varying(100),
    vessel_name character varying(255),
    container_number character varying(100),
    departure_port character varying(100),
    destination_port character varying(100),
    estimated_arrival timestamp without time zone,
    actual_arrival timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    synced_from character varying(20),
    synced_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    raw_data jsonb
);


ALTER TABLE public.blockchain_shipments OWNER TO cecbs;

--
-- Name: TABLE blockchain_shipments; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.blockchain_shipments IS 'Synced copy of shipments from blockchain CouchDB state database for fast querying';


--
-- Name: COLUMN blockchain_shipments.synced_from; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.blockchain_shipments.synced_from IS 'Organization that synced this data (ecta, ecx, banks, nbe, customs, shipping)';


--
-- Name: COLUMN blockchain_shipments.raw_data; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.blockchain_shipments.raw_data IS 'Original JSON document from CouchDB for reference';


--
-- Name: border_crossings; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.border_crossings (
    crossing_id character varying(50) NOT NULL,
    shipment_id character varying(50),
    contract_id character varying(50),
    exporter_id character varying(50),
    border_post character varying(100),
    border_country character varying(50),
    crossing_type character varying(30),
    transit_country character varying(50),
    final_destination character varying(100),
    exit_permit_number character varying(100),
    exit_permit_issued date,
    exit_permit_expiry date,
    customs_declaration character varying(100),
    transport_mode character varying(30),
    vehicle_number character varying(50),
    driver_name character varying(200),
    driver_license character varying(50),
    seal_number character varying(50),
    cargo_weight numeric(12,2),
    number_of_bags integer,
    container_numbers jsonb DEFAULT '[]'::jsonb,
    status character varying(30) DEFAULT 'PENDING'::character varying,
    departure_date date,
    crossing_date date,
    arrival_date date,
    transit_duration integer,
    ethiopian_customs_officer character varying(200),
    ethiopian_clearance_date timestamp without time zone,
    ethiopian_clearance_ref character varying(100),
    border_customs_officer character varying(200),
    border_clearance_date timestamp without time zone,
    border_clearance_ref character varying(100),
    border_stamp_url text,
    last_known_location character varying(200),
    last_location_update timestamp without time zone,
    tracking_number character varying(100),
    checkpoints_passed jsonb DEFAULT '[]'::jsonb,
    delay_reported boolean DEFAULT false,
    delay_reason text,
    delay_duration integer,
    issues_encountered jsonb DEFAULT '[]'::jsonb,
    verified_by text,
    verified_by_msp character varying(50),
    verification_date timestamp without time zone,
    compliance_status character varying(30),
    compliance_notes text,
    recorded_by text,
    recorded_by_msp character varying(50),
    last_updated_by text,
    last_updated_by_msp character varying(50),
    comments text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.border_crossings OWNER TO cecbs;

--
-- Name: TABLE border_crossings; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.border_crossings IS 'Border crossing documentation for Ethiopian coffee exports';


--
-- Name: COLUMN border_crossings.border_post; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.border_crossings.border_post IS 'Ethiopian border posts: GALAFI (Djibouti), MOYALE (Kenya), METEMA (Sudan)';


--
-- Name: COLUMN border_crossings.crossing_type; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.border_crossings.crossing_type IS 'SEA_PORT, LAND, or AIR';


--
-- Name: COLUMN border_crossings.seal_number; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.border_crossings.seal_number IS 'Customs seal number (must be intact)';


--
-- Name: COLUMN border_crossings.transit_duration; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.border_crossings.transit_duration IS 'Days in transit from departure to arrival';


--
-- Name: COLUMN border_crossings.checkpoints_passed; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.border_crossings.checkpoints_passed IS 'Array of checkpoint names during transit';


--
-- Name: contracts; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.contracts (
    id integer NOT NULL,
    contract_id character varying(100) NOT NULL,
    exporter_id character varying(100),
    buyer_id character varying(100),
    quantity numeric(10,2),
    price_per_kg numeric(10,2),
    total_value numeric(15,2),
    payment_terms character varying(255),
    delivery_terms character varying(255),
    status character varying(50) DEFAULT 'draft'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.contracts OWNER TO cecbs;

--
-- Name: TABLE contracts; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.contracts IS 'Export contracts between parties';


--
-- Name: contracts_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.contracts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contracts_id_seq OWNER TO cecbs;

--
-- Name: contracts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.contracts_id_seq OWNED BY public.contracts.id;


--
-- Name: customs_clearances; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.customs_clearances (
    id integer NOT NULL,
    clearance_id character varying(100) NOT NULL,
    shipment_id character varying(100),
    declaration_id character varying(100),
    clearance_date timestamp without time zone,
    exit_point character varying(255),
    status character varying(50) DEFAULT 'pending'::character varying,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    clearance_number character varying(50),
    cleared_by character varying(100),
    cleared_date date,
    duty_amount numeric(15,2),
    tax_amount numeric(15,2),
    remarks text,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.customs_clearances OWNER TO cecbs;

--
-- Name: TABLE customs_clearances; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.customs_clearances IS 'Customs clearance approvals';


--
-- Name: customs_clearances_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.customs_clearances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customs_clearances_id_seq OWNER TO cecbs;

--
-- Name: customs_clearances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.customs_clearances_id_seq OWNED BY public.customs_clearances.id;


--
-- Name: customs_declarations; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.customs_declarations (
    id integer NOT NULL,
    declaration_id character varying(100) NOT NULL,
    shipment_id character varying(100),
    declaration_number character varying(100),
    declared_value numeric(15,2),
    duty_amount numeric(15,2),
    status character varying(50) DEFAULT 'pending'::character varying,
    submitted_date timestamp without time zone,
    cleared_date timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    exporter_id character varying(100),
    declaration_type character varying(50) DEFAULT 'STANDARD'::character varying,
    hs_code character varying(20),
    quantity numeric(15,2),
    currency character varying(10) DEFAULT 'USD'::character varying,
    destination character varying(100),
    port_of_exit character varying(100),
    eudr_compliant boolean DEFAULT false,
    additional_notes text,
    customs_officer character varying(100),
    inspection_required boolean DEFAULT true,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.customs_declarations OWNER TO cecbs;

--
-- Name: TABLE customs_declarations; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.customs_declarations IS 'Customs declaration records';


--
-- Name: customs_declarations_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.customs_declarations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customs_declarations_id_seq OWNER TO cecbs;

--
-- Name: customs_declarations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.customs_declarations_id_seq OWNED BY public.customs_declarations.id;


--
-- Name: customs_inspections; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.customs_inspections (
    id integer NOT NULL,
    inspection_id character varying(50) NOT NULL,
    shipment_id character varying(50) NOT NULL,
    clearance_id character varying(50),
    inspection_type character varying(50) NOT NULL,
    inspection_date date NOT NULL,
    inspector_name character varying(100) NOT NULL,
    inspection_result character varying(50) NOT NULL,
    findings text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.customs_inspections OWNER TO cecbs;

--
-- Name: customs_inspections_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.customs_inspections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customs_inspections_id_seq OWNER TO cecbs;

--
-- Name: customs_inspections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.customs_inspections_id_seq OWNED BY public.customs_inspections.id;


--
-- Name: customs_risk_assessments; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.customs_risk_assessments (
    id integer NOT NULL,
    assessment_id character varying(50) NOT NULL,
    shipment_id character varying(50) NOT NULL,
    exporter_id character varying(50) NOT NULL,
    risk_factors jsonb NOT NULL,
    risk_level character varying(20) NOT NULL,
    inspection_required boolean DEFAULT false,
    assessed_by character varying(100) NOT NULL,
    assessment_date timestamp without time zone DEFAULT now(),
    remarks text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.customs_risk_assessments OWNER TO cecbs;

--
-- Name: customs_risk_assessments_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.customs_risk_assessments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customs_risk_assessments_id_seq OWNER TO cecbs;

--
-- Name: customs_risk_assessments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.customs_risk_assessments_id_seq OWNED BY public.customs_risk_assessments.id;


--
-- Name: documents; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.documents (
    id integer NOT NULL,
    document_id character varying(100) NOT NULL,
    shipment_id character varying(100),
    document_type character varying(100),
    document_name character varying(255),
    file_hash character varying(255),
    ipfs_hash character varying(255),
    uploaded_by integer,
    uploaded_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(50) DEFAULT 'pending'::character varying,
    verified boolean DEFAULT false,
    contract_id character varying(50),
    exporter_id character varying(50),
    file_name character varying(255),
    file_size bigint,
    mime_type character varying(100),
    ipfs_cid character varying(100),
    upload_date timestamp without time zone DEFAULT now(),
    file_path text
);


ALTER TABLE public.documents OWNER TO cecbs;

--
-- Name: TABLE documents; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.documents IS 'Shipping documents and certificates';


--
-- Name: COLUMN documents.file_path; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.documents.file_path IS 'Physical file path on server disk';


--
-- Name: document_approval_status; Type: VIEW; Schema: public; Owner: cecbs
--

CREATE VIEW public.document_approval_status AS
 SELECT d.document_id,
    aws.entity_type,
    aws.entity_id,
    d.document_type,
    d.document_name AS file_name,
    d.status AS document_status,
    aws.required_approvals,
    aws.current_approvals,
    aws.approval_status,
    aws.approved_by,
    aws.rejected_by,
    aws.rejection_reason,
    ar.required_roles,
    ar.approval_order,
        CASE
            WHEN (aws.current_approvals >= aws.required_approvals) THEN true
            ELSE false
        END AS is_fully_approved,
    d.uploaded_at,
    aws.updated_at AS approval_updated_at
   FROM ((public.documents d
     LEFT JOIN public.approval_workflow_state aws ON (((d.document_id)::text = (aws.document_id)::text)))
     LEFT JOIN public.approval_requirements ar ON ((((d.document_type)::text = (ar.document_type)::text) AND ((aws.entity_type)::text = (ar.entity_type)::text))))
  WHERE ((d.status)::text <> 'deleted'::text);


ALTER TABLE public.document_approval_status OWNER TO cecbs;

--
-- Name: VIEW document_approval_status; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON VIEW public.document_approval_status IS 'Comprehensive view of document approval progress';


--
-- Name: document_signatures; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.document_signatures (
    id integer NOT NULL,
    document_id character varying(255) NOT NULL,
    signature_type character varying(50) NOT NULL,
    signed_by character varying(500),
    signed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    approval_level integer DEFAULT 1,
    approval_order integer DEFAULT 1,
    signed_by_role character varying(100),
    approval_status character varying(50) DEFAULT 'pending'::character varying,
    approval_notes text,
    requires_further_approval boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.document_signatures OWNER TO cecbs;

--
-- Name: document_signatures_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.document_signatures_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.document_signatures_id_seq OWNER TO cecbs;

--
-- Name: document_signatures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.document_signatures_id_seq OWNED BY public.document_signatures.id;


--
-- Name: document_verifications; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.document_verifications (
    id integer NOT NULL,
    document_id character varying(100),
    verified_by integer,
    verification_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(50),
    notes text,
    verification_id character varying(50),
    verified_by_org character varying(50),
    verified boolean,
    remarks text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.document_verifications OWNER TO cecbs;

--
-- Name: document_verifications_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.document_verifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.document_verifications_id_seq OWNER TO cecbs;

--
-- Name: document_verifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.document_verifications_id_seq OWNED BY public.document_verifications.id;


--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.documents_id_seq OWNER TO cecbs;

--
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.documents_id_seq OWNED BY public.documents.id;


--
-- Name: email_logs; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.email_logs (
    id integer NOT NULL,
    recipient character varying(255) NOT NULL,
    subject character varying(500) NOT NULL,
    body text NOT NULL,
    status character varying(50) NOT NULL,
    sent_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    delivered_at timestamp without time zone,
    opened_at timestamp without time zone,
    clicked_at timestamp without time zone,
    error text
);


ALTER TABLE public.email_logs OWNER TO cecbs;

--
-- Name: email_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.email_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.email_logs_id_seq OWNER TO cecbs;

--
-- Name: email_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.email_logs_id_seq OWNED BY public.email_logs.id;


--
-- Name: export_proceeds_repatriation; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.export_proceeds_repatriation (
    repatriation_id character varying(50) NOT NULL,
    payment_id character varying(50),
    contract_id character varying(50),
    shipment_id character varying(50),
    exporter_id character varying(50),
    export_amount numeric(15,2) NOT NULL,
    currency character varying(10) DEFAULT 'USD'::character varying,
    required_retention numeric(15,2),
    required_conversion numeric(15,2),
    retention_percentage numeric(5,2) DEFAULT 40.0,
    conversion_percentage numeric(5,2) DEFAULT 60.0,
    repatriated_amount numeric(15,2) DEFAULT 0,
    converted_amount numeric(15,2) DEFAULT 0,
    converted_amount_birr numeric(15,2) DEFAULT 0,
    exchange_rate numeric(10,4),
    fcy_account_number character varying(50),
    fcy_bank character varying(100),
    fcy_bank_bic character varying(20),
    status character varying(30) DEFAULT 'PENDING'::character varying,
    compliance_deadline timestamp without time zone NOT NULL,
    shipment_date date,
    repatriation_date timestamp without time zone,
    compliance_date timestamp without time zone,
    days_remaining integer,
    is_overdue boolean DEFAULT false,
    verified_by text,
    verified_by_msp character varying(50),
    verification_date timestamp without time zone,
    verification_ref character varying(100),
    verification_notes text,
    penalty_amount numeric(15,2),
    penalty_currency character varying(10),
    waiver_requested boolean DEFAULT false,
    waiver_approved boolean DEFAULT false,
    waiver_reason text,
    waiver_date timestamp without time zone,
    swift_references jsonb DEFAULT '[]'::jsonb,
    bank_certificate text,
    recorded_by text,
    recorded_by_msp character varying(50),
    last_updated_by text,
    last_updated_by_msp character varying(50),
    comments text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.export_proceeds_repatriation OWNER TO cecbs;

--
-- Name: TABLE export_proceeds_repatriation; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.export_proceeds_repatriation IS 'Tracks export proceeds repatriation compliance (NBE Directive FXD/01/2024)';


--
-- Name: COLUMN export_proceeds_repatriation.retention_percentage; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.export_proceeds_repatriation.retention_percentage IS '40% USD retention requirement';


--
-- Name: COLUMN export_proceeds_repatriation.conversion_percentage; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.export_proceeds_repatriation.conversion_percentage IS '60% Birr conversion requirement';


--
-- Name: COLUMN export_proceeds_repatriation.compliance_deadline; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.export_proceeds_repatriation.compliance_deadline IS '120 days from shipment date';


--
-- Name: COLUMN export_proceeds_repatriation.is_overdue; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.export_proceeds_repatriation.is_overdue IS 'Automatically set if deadline passed without compliance';


--
-- Name: exporter_applications; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.exporter_applications (
    id integer NOT NULL,
    company_name character varying(255) NOT NULL,
    tin character varying(50),
    license_number character varying(100),
    contact_person character varying(255),
    email character varying(255),
    phone character varying(50),
    address text,
    status character varying(50) DEFAULT 'pending'::character varying,
    submitted_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    reviewed_date timestamp without time zone,
    reviewed_by integer,
    rejection_reason text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    temp_username character varying(100),
    temp_password text,
    temp_credentials_sent boolean DEFAULT false,
    account_created boolean DEFAULT false,
    license_issued_date timestamp without time zone,
    license_expiry_date timestamp without time zone,
    digital_signature text,
    verification_code character varying(16),
    bank_branch character varying(255),
    bank_branch_code character varying(50),
    documents jsonb DEFAULT '[]'::jsonb,
    ecta_license_number character varying(100),
    laboratory_certificate_number character varying(100),
    exporter_type character varying(50) DEFAULT 'STANDARD'::character varying
);


ALTER TABLE public.exporter_applications OWNER TO cecbs;

--
-- Name: COLUMN exporter_applications.license_number; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.exporter_applications.license_number IS 'Generated ECTA license number upon approval';


--
-- Name: COLUMN exporter_applications.temp_username; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.exporter_applications.temp_username IS 'Temporary username for applicant to track application';


--
-- Name: COLUMN exporter_applications.temp_password; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.exporter_applications.temp_password IS 'Hashed temporary password';


--
-- Name: COLUMN exporter_applications.temp_credentials_sent; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.exporter_applications.temp_credentials_sent IS 'Whether temporary credentials were sent to applicant';


--
-- Name: COLUMN exporter_applications.account_created; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.exporter_applications.account_created IS 'Whether full exporter account was created upon approval';


--
-- Name: COLUMN exporter_applications.license_issued_date; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.exporter_applications.license_issued_date IS 'Date when license was issued';


--
-- Name: COLUMN exporter_applications.license_expiry_date; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.exporter_applications.license_expiry_date IS 'License expiry date';


--
-- Name: COLUMN exporter_applications.digital_signature; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.exporter_applications.digital_signature IS 'Digital signature of the license document';


--
-- Name: COLUMN exporter_applications.verification_code; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.exporter_applications.verification_code IS 'Verification code for license authenticity';


--
-- Name: exporter_applications_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.exporter_applications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exporter_applications_id_seq OWNER TO cecbs;

--
-- Name: exporter_applications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.exporter_applications_id_seq OWNED BY public.exporter_applications.id;


--
-- Name: forex_allocations; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.forex_allocations (
    id integer NOT NULL,
    allocation_id character varying(100) NOT NULL,
    shipment_id character varying(100),
    lc_number character varying(100),
    amount_usd numeric(15,2),
    exchange_rate numeric(10,4),
    amount_local numeric(15,2),
    allocation_date date,
    status character varying(50) DEFAULT 'pending'::character varying,
    approved_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    contract_id character varying(50),
    exporter_id character varying(50),
    amount_etb numeric(15,2),
    approved_by_name character varying(100),
    utilized_amount numeric(15,2) DEFAULT 0,
    remarks text,
    updated_at timestamp without time zone DEFAULT now(),
    confirmed_by character varying(255),
    confirmed_at timestamp without time zone
);


ALTER TABLE public.forex_allocations OWNER TO cecbs;

--
-- Name: TABLE forex_allocations; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.forex_allocations IS 'Foreign exchange allocations';


--
-- Name: COLUMN forex_allocations.confirmed_by; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.forex_allocations.confirmed_by IS 'NBE officer who confirmed the forex request (two-step workflow)';


--
-- Name: COLUMN forex_allocations.confirmed_at; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.forex_allocations.confirmed_at IS 'Timestamp when forex request was confirmed by NBE';


--
-- Name: forex_allocations_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.forex_allocations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.forex_allocations_id_seq OWNER TO cecbs;

--
-- Name: forex_allocations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.forex_allocations_id_seq OWNED BY public.forex_allocations.id;


--
-- Name: lab_test_results; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.lab_test_results (
    id integer NOT NULL,
    test_id character varying(50) NOT NULL,
    inspection_id character varying(50) NOT NULL,
    test_type character varying(50) NOT NULL,
    test_date date NOT NULL,
    result character varying(50) NOT NULL,
    details jsonb,
    tested_by character varying(100),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.lab_test_results OWNER TO cecbs;

--
-- Name: lab_test_results_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.lab_test_results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lab_test_results_id_seq OWNER TO cecbs;

--
-- Name: lab_test_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.lab_test_results_id_seq OWNED BY public.lab_test_results.id;


--
-- Name: lc_discrepancies; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.lc_discrepancies (
    discrepancy_id character varying(50) NOT NULL,
    lc_id character varying(50) NOT NULL,
    document character varying(100),
    issue text,
    reported_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    resolved_date timestamp without time zone,
    resolution text,
    status character varying(30) DEFAULT 'OPEN'::character varying,
    reported_by text,
    reported_by_msp character varying(50),
    resolved_by text,
    resolved_by_msp character varying(50),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.lc_discrepancies OWNER TO cecbs;

--
-- Name: TABLE lc_discrepancies; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.lc_discrepancies IS 'Letter of Credit document discrepancies (UCP 600 Article 14)';


--
-- Name: COLUMN lc_discrepancies.status; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.lc_discrepancies.status IS 'OPEN, RESOLVED, or WAIVED';


--
-- Name: letters_of_credit; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.letters_of_credit (
    id integer NOT NULL,
    lc_number character varying(100) NOT NULL,
    shipment_id character varying(100),
    issuing_bank character varying(255),
    advising_bank character varying(255),
    beneficiary character varying(255),
    applicant character varying(255),
    amount numeric(15,2),
    currency character varying(10) DEFAULT 'USD'::character varying,
    issue_date date,
    expiry_date date,
    status character varying(50) DEFAULT 'draft'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    approved_by character varying(500),
    approved_by_msp character varying(100),
    issued_by character varying(500),
    issued_by_msp character varying(100),
    last_updated_by character varying(500),
    last_updated_by_msp character varying(100)
);


ALTER TABLE public.letters_of_credit OWNER TO cecbs;

--
-- Name: TABLE letters_of_credit; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.letters_of_credit IS 'LC payment instruments';


--
-- Name: COLUMN letters_of_credit.approved_by; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.letters_of_credit.approved_by IS 'X.509 certificate of user who approved the LC';


--
-- Name: COLUMN letters_of_credit.approved_by_msp; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.letters_of_credit.approved_by_msp IS 'MSP ID of organization that approved the LC (e.g., BanksMSP)';


--
-- Name: COLUMN letters_of_credit.issued_by; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.letters_of_credit.issued_by IS 'X.509 certificate of user who issued the LC';


--
-- Name: COLUMN letters_of_credit.issued_by_msp; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.letters_of_credit.issued_by_msp IS 'MSP ID of organization that issued the LC';


--
-- Name: COLUMN letters_of_credit.last_updated_by; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.letters_of_credit.last_updated_by IS 'X.509 certificate of last user to update the LC';


--
-- Name: COLUMN letters_of_credit.last_updated_by_msp; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.letters_of_credit.last_updated_by_msp IS 'MSP ID of last organization to update the LC';


--
-- Name: letters_of_credit_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.letters_of_credit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.letters_of_credit_id_seq OWNER TO cecbs;

--
-- Name: letters_of_credit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.letters_of_credit_id_seq OWNED BY public.letters_of_credit.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer,
    title character varying(255),
    message text,
    type character varying(50),
    read boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    recipient_email character varying(255),
    recipient_phone character varying(50),
    recipient_name character varying(255),
    organization character varying(100),
    notification_type character varying(100),
    priority character varying(20) DEFAULT 'NORMAL'::character varying,
    category character varying(50),
    channels text[],
    email_subject character varying(255),
    email_html text,
    email_attachments jsonb,
    sms_message text,
    push_data jsonb,
    in_app_read boolean DEFAULT false,
    in_app_read_at timestamp without time zone,
    webhook_url text,
    webhook_payload jsonb,
    webhook_headers jsonb,
    action_url text,
    action_label character varying(100),
    resource_type character varying(100),
    resource_id character varying(255),
    contract_id character varying(255),
    shipment_id character varying(255),
    status character varying(50) DEFAULT 'PENDING'::character varying,
    email_sent boolean DEFAULT false,
    email_sent_at timestamp without time zone,
    email_error text,
    sms_sent boolean DEFAULT false,
    sms_sent_at timestamp without time zone,
    sms_error text,
    webhook_sent boolean DEFAULT false,
    webhook_sent_at timestamp without time zone,
    webhook_response_status integer,
    webhook_error text,
    retry_count integer DEFAULT 0,
    max_retries integer DEFAULT 3,
    next_retry_at timestamp without time zone,
    scheduled_for timestamp without time zone,
    expires_at timestamp without time zone,
    metadata jsonb,
    tags text[],
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    sent_at timestamp without time zone
);


ALTER TABLE public.notifications OWNER TO cecbs;

--
-- Name: notification_delivery_stats; Type: VIEW; Schema: public; Owner: cecbs
--

CREATE VIEW public.notification_delivery_stats AS
 SELECT notifications.notification_type,
    notifications.status,
    count(*) AS count,
    count(*) FILTER (WHERE (notifications.email_sent = true)) AS emails_sent,
    count(*) FILTER (WHERE (notifications.sms_sent = true)) AS sms_sent,
    count(*) FILTER (WHERE (notifications.webhook_sent = true)) AS webhooks_sent,
    avg(EXTRACT(epoch FROM (notifications.sent_at - notifications.created_at))) AS avg_delivery_time_seconds
   FROM public.notifications
  WHERE (notifications.created_at > (now() - '7 days'::interval))
  GROUP BY notifications.notification_type, notifications.status;


ALTER TABLE public.notification_delivery_stats OWNER TO cecbs;

--
-- Name: VIEW notification_delivery_stats; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON VIEW public.notification_delivery_stats IS 'Notification delivery statistics (last 7 days)';


--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.notification_preferences (
    user_id character varying(255) NOT NULL,
    email_enabled boolean DEFAULT true,
    sms_enabled boolean DEFAULT false,
    webhook_enabled boolean DEFAULT false,
    events jsonb DEFAULT '{}'::jsonb NOT NULL,
    phone character varying(20),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notification_preferences OWNER TO cecbs;

--
-- Name: notification_templates; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.notification_templates (
    id integer NOT NULL,
    template_code character varying(100) NOT NULL,
    template_name character varying(255) NOT NULL,
    description text,
    subject_template text,
    body_template text NOT NULL,
    sms_template text,
    required_variables text[],
    default_channels text[],
    default_priority character varying(20) DEFAULT 'NORMAL'::character varying,
    category character varying(50),
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notification_templates OWNER TO cecbs;

--
-- Name: TABLE notification_templates; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.notification_templates IS 'Reusable notification templates with variable substitution';


--
-- Name: notification_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.notification_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notification_templates_id_seq OWNER TO cecbs;

--
-- Name: notification_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.notification_templates_id_seq OWNED BY public.notification_templates.id;


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_id_seq OWNER TO cecbs;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: payment_confirmations; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.payment_confirmations (
    id integer NOT NULL,
    confirmation_id character varying(50) NOT NULL,
    payment_id character varying(50) NOT NULL,
    confirmed_by character varying(50) NOT NULL,
    confirmed_by_org character varying(50) NOT NULL,
    confirmation_date timestamp without time zone DEFAULT now(),
    confirmation_type character varying(50) NOT NULL,
    reference_number character varying(100),
    remarks text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.payment_confirmations OWNER TO cecbs;

--
-- Name: payment_confirmations_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.payment_confirmations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_confirmations_id_seq OWNER TO cecbs;

--
-- Name: payment_confirmations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.payment_confirmations_id_seq OWNED BY public.payment_confirmations.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    payment_id character varying(100) NOT NULL,
    lc_number character varying(100),
    shipment_id character varying(100),
    amount numeric(15,2),
    currency character varying(10) DEFAULT 'USD'::character varying,
    payment_date date,
    status character varying(50) DEFAULT 'pending'::character varying,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    contract_id character varying(50),
    exporter_id character varying(50),
    payment_method character varying(50)
);


ALTER TABLE public.payments OWNER TO cecbs;

--
-- Name: TABLE payments; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.payments IS 'Payment transactions';


--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payments_id_seq OWNER TO cecbs;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: pending_notifications; Type: VIEW; Schema: public; Owner: cecbs
--

CREATE VIEW public.pending_notifications AS
 SELECT notifications.id,
    notifications.user_id,
    notifications.title,
    notifications.notification_type,
    notifications.priority,
    notifications.channels,
    notifications.status,
    notifications.retry_count,
    notifications.scheduled_for,
    notifications.created_at
   FROM public.notifications
  WHERE (((notifications.status)::text = ANY ((ARRAY['PENDING'::character varying, 'RETRY'::character varying])::text[])) AND ((notifications.scheduled_for IS NULL) OR (notifications.scheduled_for <= now())) AND ((notifications.expires_at IS NULL) OR (notifications.expires_at > now())))
  ORDER BY notifications.priority DESC, notifications.created_at;


ALTER TABLE public.pending_notifications OWNER TO cecbs;

--
-- Name: VIEW pending_notifications; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON VIEW public.pending_notifications IS 'Notifications pending delivery';


--
-- Name: post_delivery_checklist; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.post_delivery_checklist (
    id integer NOT NULL,
    shipment_id character varying(100) NOT NULL,
    item_type character varying(50) NOT NULL,
    description text NOT NULL,
    display_order integer NOT NULL,
    completed boolean DEFAULT false,
    completed_at timestamp without time zone,
    notes text
);


ALTER TABLE public.post_delivery_checklist OWNER TO cecbs;

--
-- Name: TABLE post_delivery_checklist; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.post_delivery_checklist IS 'Checklist items for post-delivery workflow';


--
-- Name: post_delivery_checklist_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.post_delivery_checklist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.post_delivery_checklist_id_seq OWNER TO cecbs;

--
-- Name: post_delivery_checklist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.post_delivery_checklist_id_seq OWNED BY public.post_delivery_checklist.id;


--
-- Name: post_delivery_issues; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.post_delivery_issues (
    id integer NOT NULL,
    shipment_id character varying(100) NOT NULL,
    issue_type character varying(50) NOT NULL,
    severity character varying(20) NOT NULL,
    message text NOT NULL,
    resolved boolean DEFAULT false,
    resolved_at timestamp without time zone,
    resolved_by integer,
    resolution_notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT post_delivery_issues_issue_type_check CHECK (((issue_type)::text = ANY ((ARRAY['PAYMENT_OVERDUE'::character varying, 'FOREX_DELAYED'::character varying, 'LC_ISSUE'::character varying, 'AUDIT_REQUIRED'::character varying, 'COMPLIANCE_ISSUE'::character varying])::text[]))),
    CONSTRAINT post_delivery_issues_severity_check CHECK (((severity)::text = ANY ((ARRAY['LOW'::character varying, 'MEDIUM'::character varying, 'HIGH'::character varying, 'CRITICAL'::character varying])::text[])))
);


ALTER TABLE public.post_delivery_issues OWNER TO cecbs;

--
-- Name: TABLE post_delivery_issues; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.post_delivery_issues IS 'Issues and alerts for delayed/problematic post-delivery processes';


--
-- Name: post_delivery_issues_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.post_delivery_issues_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.post_delivery_issues_id_seq OWNER TO cecbs;

--
-- Name: post_delivery_issues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.post_delivery_issues_id_seq OWNED BY public.post_delivery_issues.id;


--
-- Name: post_delivery_notifications; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.post_delivery_notifications (
    id integer NOT NULL,
    shipment_id character varying(100) NOT NULL,
    notification_type character varying(50) NOT NULL,
    recipient_role character varying(50) NOT NULL,
    message text NOT NULL,
    sent boolean DEFAULT false,
    sent_at timestamp without time zone,
    read boolean DEFAULT false,
    read_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT post_delivery_notifications_recipient_role_check CHECK (((recipient_role)::text = ANY ((ARRAY['BANK'::character varying, 'NBE'::character varying, 'ECTA'::character varying, 'EXPORTER'::character varying, 'ADMIN'::character varying])::text[])))
);


ALTER TABLE public.post_delivery_notifications OWNER TO cecbs;

--
-- Name: TABLE post_delivery_notifications; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.post_delivery_notifications IS 'Notifications sent to stakeholders during post-delivery workflow';


--
-- Name: post_delivery_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.post_delivery_notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.post_delivery_notifications_id_seq OWNER TO cecbs;

--
-- Name: post_delivery_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.post_delivery_notifications_id_seq OWNED BY public.post_delivery_notifications.id;


--
-- Name: post_delivery_tracking; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.post_delivery_tracking (
    id integer NOT NULL,
    tracking_id character varying(100) NOT NULL,
    shipment_id character varying(100),
    arrival_date timestamp without time zone,
    warehouse_location character varying(255),
    quality_recheck_status character varying(50),
    status character varying(50) DEFAULT 'pending'::character varying,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    contract_id character varying(100),
    exporter_id character varying(100),
    delivery_date timestamp without time zone,
    payment_received boolean DEFAULT false,
    payment_received_date timestamp without time zone,
    payment_amount numeric(15,2),
    payment_currency character varying(3),
    swift_reference character varying(100),
    forex_repatriated boolean DEFAULT false,
    forex_repatriation_date timestamp without time zone,
    forex_amount numeric(15,2),
    forex_rate numeric(10,4),
    lc_used boolean DEFAULT false,
    lc_settled boolean DEFAULT false,
    lc_settlement_date timestamp without time zone,
    lc_reference character varying(100),
    ecta_audit_completed boolean DEFAULT false,
    ecta_audit_date timestamp without time zone,
    ecta_audit_result character varying(20),
    ecta_audit_notes text,
    contract_closed boolean DEFAULT false,
    contract_closure_date timestamp without time zone,
    overall_status character varying(20) DEFAULT 'PENDING'::character varying,
    completion_percentage integer DEFAULT 0,
    expected_completion_date timestamp without time zone,
    created_by integer,
    updated_by integer,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT post_delivery_tracking_completion_percentage_check CHECK (((completion_percentage >= 0) AND (completion_percentage <= 100))),
    CONSTRAINT post_delivery_tracking_ecta_audit_result_check CHECK (((ecta_audit_result)::text = ANY ((ARRAY['PASSED'::character varying, 'FAILED'::character varying, 'PENDING'::character varying])::text[]))),
    CONSTRAINT post_delivery_tracking_overall_status_check CHECK (((overall_status)::text = ANY ((ARRAY['PENDING'::character varying, 'IN_PROGRESS'::character varying, 'COMPLETED'::character varying, 'DELAYED'::character varying, 'ISSUE'::character varying])::text[])))
);


ALTER TABLE public.post_delivery_tracking OWNER TO cecbs;

--
-- Name: TABLE post_delivery_tracking; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.post_delivery_tracking IS 'Tracks post-delivery workflow: payment, forex, LC, audit, closure';


--
-- Name: post_delivery_tracking_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.post_delivery_tracking_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.post_delivery_tracking_id_seq OWNER TO cecbs;

--
-- Name: post_delivery_tracking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.post_delivery_tracking_id_seq OWNED BY public.post_delivery_tracking.id;


--
-- Name: pre_shipment_inspections; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.pre_shipment_inspections (
    inspection_id character varying(50) NOT NULL,
    contract_id character varying(50),
    shipment_id character varying(50),
    exporter_id character varying(50),
    inspection_agency character varying(100),
    inspector_name character varying(200),
    inspector_license character varying(100),
    requested_by text,
    request_date timestamp without time zone,
    inspection_date date,
    inspection_location character varying(200),
    contract_quantity numeric(12,2),
    contract_grade character varying(50),
    contract_type character varying(50),
    packaging_type character varying(50),
    inspected_quantity numeric(12,2),
    quantity_variance numeric(12,2),
    quantity_acceptable boolean DEFAULT false,
    actual_grade character varying(50),
    cupping_score numeric(5,2),
    defects_count integer,
    moisture_content numeric(5,2),
    bean_size character varying(20),
    quality_acceptable boolean DEFAULT false,
    bags_inspected integer,
    packaging_condition character varying(30),
    packaging_acceptable boolean DEFAULT false,
    status character varying(30) DEFAULT 'REQUESTED'::character varying,
    overall_result character varying(30),
    inspection_notes text,
    recommendations text,
    certificate_number character varying(100),
    certificate_issued timestamp without time zone,
    certificate_expiry date,
    certificate_url text,
    samples_taken integer,
    sample_ids jsonb DEFAULT '[]'::jsonb,
    lab_test_required boolean DEFAULT false,
    lab_test_completed boolean DEFAULT false,
    lab_test_results text,
    issues_found jsonb DEFAULT '[]'::jsonb,
    corrective_actions jsonb DEFAULT '[]'::jsonb,
    re_inspection_required boolean DEFAULT false,
    approved_by text,
    approved_by_msp character varying(50),
    approval_date timestamp without time zone,
    rejected_by text,
    rejected_by_msp character varying(50),
    rejection_reason text,
    recorded_by text,
    recorded_by_msp character varying(50),
    last_updated_by text,
    last_updated_by_msp character varying(50),
    comments text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.pre_shipment_inspections OWNER TO cecbs;

--
-- Name: TABLE pre_shipment_inspections; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.pre_shipment_inspections IS 'Pre-shipment quality inspections by international agencies (SGS, Intertek, Bureau Veritas)';


--
-- Name: COLUMN pre_shipment_inspections.cupping_score; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.pre_shipment_inspections.cupping_score IS 'Coffee cupping score (0-100 SCA scale)';


--
-- Name: COLUMN pre_shipment_inspections.moisture_content; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.pre_shipment_inspections.moisture_content IS 'Coffee moisture percentage (target: 11-12%)';


--
-- Name: COLUMN pre_shipment_inspections.overall_result; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.pre_shipment_inspections.overall_result IS 'PASS, FAIL, or CONDITIONAL_PASS';


--
-- Name: COLUMN pre_shipment_inspections.certificate_expiry; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.pre_shipment_inspections.certificate_expiry IS 'Certificate valid for 90 days from issue';


--
-- Name: quality_certificates; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.quality_certificates (
    id integer NOT NULL,
    certificate_number character varying(50) NOT NULL,
    inspection_id character varying(50) NOT NULL,
    exporter_id character varying(50) NOT NULL,
    coffee_type character varying(100) NOT NULL,
    quantity numeric(15,2) NOT NULL,
    grade character varying(20) NOT NULL,
    issue_date date NOT NULL,
    expiry_date date,
    issued_by character varying(100) NOT NULL,
    certificate_hash character varying(128),
    ipfs_cid character varying(100),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.quality_certificates OWNER TO cecbs;

--
-- Name: quality_certificates_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.quality_certificates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quality_certificates_id_seq OWNER TO cecbs;

--
-- Name: quality_certificates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.quality_certificates_id_seq OWNED BY public.quality_certificates.id;


--
-- Name: quality_inspections; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.quality_inspections (
    id integer NOT NULL,
    shipment_id character varying(100),
    inspector_id integer,
    inspection_date timestamp without time zone,
    grade character varying(50),
    moisture_content numeric(5,2),
    defect_count integer,
    cup_quality character varying(50),
    status character varying(50),
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    inspection_id character varying(50),
    exporter_id character varying(50),
    contract_id character varying(50),
    coffee_type character varying(100),
    quantity numeric(15,2),
    sample_size numeric(10,2),
    requested_date date,
    inspector_name character varying(100),
    screen_size integer,
    passed boolean,
    certification_number character varying(50),
    remarks text,
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.quality_inspections OWNER TO cecbs;

--
-- Name: quality_inspections_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.quality_inspections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.quality_inspections_id_seq OWNER TO cecbs;

--
-- Name: quality_inspections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.quality_inspections_id_seq OWNED BY public.quality_inspections.id;


--
-- Name: recent_audit_logs; Type: VIEW; Schema: public; Owner: cecbs
--

CREATE VIEW public.recent_audit_logs AS
 SELECT audit_logs.id,
    audit_logs.event_type,
    audit_logs.event_category,
    audit_logs.severity,
    audit_logs.username,
    audit_logs.user_role,
    audit_logs.action,
    audit_logs.resource_type,
    audit_logs.resource_id,
    audit_logs.ip_address,
    audit_logs."timestamp" AS created_at
   FROM public.audit_logs
  WHERE (audit_logs."timestamp" > (now() - '30 days'::interval))
  ORDER BY audit_logs."timestamp" DESC;


ALTER TABLE public.recent_audit_logs OWNER TO cecbs;

--
-- Name: VIEW recent_audit_logs; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON VIEW public.recent_audit_logs IS 'Audit logs from the last 30 days';


--
-- Name: roles; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    permissions jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.roles OWNER TO cecbs;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO cecbs;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: shipment_locations; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.shipment_locations (
    id integer NOT NULL,
    shipment_id character varying(50) NOT NULL,
    latitude numeric(10,8),
    longitude numeric(11,8),
    location_name character varying(255),
    recorded_at timestamp without time zone NOT NULL,
    vessel_name character varying(100),
    container_number character varying(50),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.shipment_locations OWNER TO cecbs;

--
-- Name: shipment_locations_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.shipment_locations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shipment_locations_id_seq OWNER TO cecbs;

--
-- Name: shipment_locations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.shipment_locations_id_seq OWNED BY public.shipment_locations.id;


--
-- Name: shipment_status_history; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.shipment_status_history (
    id integer NOT NULL,
    shipment_id character varying(100),
    status character varying(50),
    changed_by integer,
    changed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    notes text,
    location character varying(255),
    updated_by character varying(50),
    update_date timestamp without time zone DEFAULT now(),
    remarks text
);


ALTER TABLE public.shipment_status_history OWNER TO cecbs;

--
-- Name: shipment_status_history_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.shipment_status_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shipment_status_history_id_seq OWNER TO cecbs;

--
-- Name: shipment_status_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.shipment_status_history_id_seq OWNED BY public.shipment_status_history.id;


--
-- Name: shipments; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.shipments (
    id integer NOT NULL,
    shipment_id character varying(100) NOT NULL,
    contract_id character varying(100),
    exporter_id character varying(100),
    buyer_id character varying(100),
    origin character varying(100),
    destination character varying(100),
    quantity numeric(10,2),
    grade character varying(50),
    status character varying(50) DEFAULT 'draft'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.shipments OWNER TO cecbs;

--
-- Name: TABLE shipments; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.shipments IS 'Coffee shipment records';


--
-- Name: shipments_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.shipments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.shipments_id_seq OWNER TO cecbs;

--
-- Name: shipments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.shipments_id_seq OWNED BY public.shipments.id;


--
-- Name: sms_logs; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.sms_logs (
    id integer NOT NULL,
    phone character varying(20) NOT NULL,
    message text NOT NULL,
    status character varying(50) NOT NULL,
    provider character varying(50) NOT NULL,
    sent_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    delivered_at timestamp without time zone,
    error text
);


ALTER TABLE public.sms_logs OWNER TO cecbs;

--
-- Name: sms_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.sms_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sms_logs_id_seq OWNER TO cecbs;

--
-- Name: sms_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.sms_logs_id_seq OWNED BY public.sms_logs.id;


--
-- Name: sync_status; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.sync_status (
    id integer NOT NULL,
    couch_instance character varying(50) NOT NULL,
    database_name character varying(100) NOT NULL,
    last_sync timestamp without time zone,
    last_seq character varying(100),
    documents_synced integer,
    status character varying(50),
    error_message text
);


ALTER TABLE public.sync_status OWNER TO cecbs;

--
-- Name: TABLE sync_status; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.sync_status IS 'Tracks synchronization status between CouchDB and PostgreSQL';


--
-- Name: COLUMN sync_status.last_seq; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON COLUMN public.sync_status.last_seq IS 'CouchDB sequence number for incremental sync (future enhancement)';


--
-- Name: sync_status_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.sync_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sync_status_id_seq OWNER TO cecbs;

--
-- Name: sync_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.sync_status_id_seq OWNED BY public.sync_status.id;


--
-- Name: system_alerts; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.system_alerts (
    id integer NOT NULL,
    alert_type character varying(100) NOT NULL,
    severity character varying(50) NOT NULL,
    title character varying(500) NOT NULL,
    message text NOT NULL,
    metadata jsonb,
    resolved boolean DEFAULT false,
    resolved_at timestamp without time zone,
    resolved_by character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_alerts OWNER TO cecbs;

--
-- Name: system_alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.system_alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.system_alerts_id_seq OWNER TO cecbs;

--
-- Name: system_alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.system_alerts_id_seq OWNED BY public.system_alerts.id;


--
-- Name: user_unread_notifications; Type: VIEW; Schema: public; Owner: cecbs
--

CREATE VIEW public.user_unread_notifications AS
 SELECT n.id,
    n.user_id,
    n.title,
    n.message,
    n.notification_type,
    n.priority,
    n.action_url,
    n.action_label,
    n.resource_type,
    n.resource_id,
    n.created_at
   FROM public.notifications n
  WHERE (('IN_APP'::text = ANY (n.channels)) AND (n.in_app_read = false) AND ((n.status)::text = ANY ((ARRAY['SENT'::character varying, 'DELIVERED'::character varying])::text[])))
  ORDER BY n.priority DESC, n.created_at DESC;


ALTER TABLE public.user_unread_notifications OWNER TO cecbs;

--
-- Name: VIEW user_unread_notifications; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON VIEW public.user_unread_notifications IS 'Unread in-app notifications per user';


--
-- Name: users; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    role character varying(50) NOT NULL,
    organization character varying(100) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    full_name character varying(255),
    exporter_id character varying(50),
    ecta_license character varying(100),
    phone character varying(50),
    bank_name character varying(255),
    bank_account_number character varying(100),
    bank_branch character varying(255),
    bank_branch_code character varying(50),
    permissions text,
    last_login timestamp without time zone,
    is_active boolean DEFAULT true
);


ALTER TABLE public.users OWNER TO cecbs;

--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON TABLE public.users IS 'System users with roles and permissions';


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO cecbs;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: v_pending_ecta_audits; Type: VIEW; Schema: public; Owner: cecbs
--

CREATE VIEW public.v_pending_ecta_audits AS
 SELECT pdt.shipment_id,
    pdt.contract_id,
    pdt.exporter_id,
    pdt.delivery_date,
    pdt.payment_received,
    pdt.forex_repatriated,
    EXTRACT(day FROM (CURRENT_TIMESTAMP - (pdt.delivery_date)::timestamp with time zone)) AS days_since_delivery
   FROM public.post_delivery_tracking pdt
  WHERE ((pdt.payment_received = true) AND (pdt.forex_repatriated = true) AND (pdt.ecta_audit_completed = false) AND ((pdt.overall_status)::text <> 'COMPLETED'::text))
  ORDER BY pdt.delivery_date;


ALTER TABLE public.v_pending_ecta_audits OWNER TO cecbs;

--
-- Name: VIEW v_pending_ecta_audits; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON VIEW public.v_pending_ecta_audits IS 'Shipments ready for ECTA final audit';


--
-- Name: v_pending_forex; Type: VIEW; Schema: public; Owner: cecbs
--

CREATE VIEW public.v_pending_forex AS
 SELECT pdt.shipment_id,
    pdt.contract_id,
    pdt.exporter_id,
    pdt.payment_received_date,
    pdt.payment_amount,
    pdt.payment_currency,
    EXTRACT(day FROM (CURRENT_TIMESTAMP - (pdt.payment_received_date)::timestamp with time zone)) AS days_since_payment,
        CASE
            WHEN (EXTRACT(day FROM (CURRENT_TIMESTAMP - (pdt.payment_received_date)::timestamp with time zone)) > (7)::numeric) THEN 'OVERDUE'::text
            WHEN (EXTRACT(day FROM (CURRENT_TIMESTAMP - (pdt.payment_received_date)::timestamp with time zone)) > (5)::numeric) THEN 'AT_RISK'::text
            ELSE 'ON_TRACK'::text
        END AS forex_status
   FROM public.post_delivery_tracking pdt
  WHERE ((pdt.payment_received = true) AND (pdt.forex_repatriated = false) AND ((pdt.overall_status)::text <> 'COMPLETED'::text))
  ORDER BY pdt.payment_received_date;


ALTER TABLE public.v_pending_forex OWNER TO cecbs;

--
-- Name: VIEW v_pending_forex; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON VIEW public.v_pending_forex IS 'Payments awaiting forex repatriation';


--
-- Name: v_pending_payments; Type: VIEW; Schema: public; Owner: cecbs
--

CREATE VIEW public.v_pending_payments AS
 SELECT pdt.shipment_id,
    pdt.contract_id,
    pdt.exporter_id,
    pdt.delivery_date,
    EXTRACT(day FROM (CURRENT_TIMESTAMP - (pdt.delivery_date)::timestamp with time zone)) AS days_since_delivery,
    pdt.expected_completion_date,
        CASE
            WHEN (EXTRACT(day FROM (CURRENT_TIMESTAMP - (pdt.delivery_date)::timestamp with time zone)) > (90)::numeric) THEN 'OVERDUE'::text
            WHEN (EXTRACT(day FROM (CURRENT_TIMESTAMP - (pdt.delivery_date)::timestamp with time zone)) > (60)::numeric) THEN 'AT_RISK'::text
            ELSE 'ON_TRACK'::text
        END AS payment_status
   FROM public.post_delivery_tracking pdt
  WHERE ((pdt.payment_received = false) AND ((pdt.overall_status)::text <> 'COMPLETED'::text))
  ORDER BY pdt.delivery_date;


ALTER TABLE public.v_pending_payments OWNER TO cecbs;

--
-- Name: VIEW v_pending_payments; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON VIEW public.v_pending_payments IS 'Shipments awaiting payment from buyer';


--
-- Name: v_post_delivery_summary; Type: VIEW; Schema: public; Owner: cecbs
--

CREATE VIEW public.v_post_delivery_summary AS
 SELECT pdt.overall_status,
    count(*) AS count,
    avg(pdt.completion_percentage) AS avg_completion,
    avg(EXTRACT(day FROM (CURRENT_TIMESTAMP - (pdt.delivery_date)::timestamp with time zone))) AS avg_days_elapsed
   FROM public.post_delivery_tracking pdt
  WHERE ((pdt.overall_status)::text <> 'COMPLETED'::text)
  GROUP BY pdt.overall_status;


ALTER TABLE public.v_post_delivery_summary OWNER TO cecbs;

--
-- Name: VIEW v_post_delivery_summary; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON VIEW public.v_post_delivery_summary IS 'Dashboard summary of post-delivery workflow status';


--
-- Name: v_ready_for_closure; Type: VIEW; Schema: public; Owner: cecbs
--

CREATE VIEW public.v_ready_for_closure AS
 SELECT pdt.shipment_id,
    pdt.contract_id,
    pdt.exporter_id,
    pdt.delivery_date,
    pdt.payment_received_date,
    pdt.forex_repatriation_date,
    pdt.ecta_audit_date,
    pdt.completion_percentage
   FROM public.post_delivery_tracking pdt
  WHERE ((pdt.payment_received = true) AND (pdt.forex_repatriated = true) AND ((pdt.lc_used = false) OR (pdt.lc_settled = true)) AND (pdt.ecta_audit_completed = true) AND (pdt.contract_closed = false))
  ORDER BY pdt.delivery_date;


ALTER TABLE public.v_ready_for_closure OWNER TO cecbs;

--
-- Name: VIEW v_ready_for_closure; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON VIEW public.v_ready_for_closure IS 'Shipments ready for contract closure';


--
-- Name: v_recent_audit_activity; Type: VIEW; Schema: public; Owner: cecbs
--

CREATE VIEW public.v_recent_audit_activity AS
 SELECT al.id,
    al.user_id,
    al.username,
    al.action,
    al.entity_type,
    al.entity_id,
    al.details,
    al.ip_address,
    al.created_at,
    u.username AS user_full_name,
    u.organization
   FROM (public.audit_log al
     LEFT JOIN public.users u ON ((al.user_id = u.id)))
  ORDER BY al.created_at DESC
 LIMIT 100;


ALTER TABLE public.v_recent_audit_activity OWNER TO cecbs;

--
-- Name: VIEW v_recent_audit_activity; Type: COMMENT; Schema: public; Owner: cecbs
--

COMMENT ON VIEW public.v_recent_audit_activity IS 'Recent audit activity with user details';


--
-- Name: webhook_logs; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.webhook_logs (
    id integer NOT NULL,
    webhook_id integer,
    event character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    status_code integer,
    error text,
    delivered_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.webhook_logs OWNER TO cecbs;

--
-- Name: webhook_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.webhook_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.webhook_logs_id_seq OWNER TO cecbs;

--
-- Name: webhook_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.webhook_logs_id_seq OWNED BY public.webhook_logs.id;


--
-- Name: webhooks; Type: TABLE; Schema: public; Owner: cecbs
--

CREATE TABLE public.webhooks (
    id integer NOT NULL,
    webhook_id character varying(100) NOT NULL,
    url character varying(500) NOT NULL,
    event_type character varying(100) NOT NULL,
    secret character varying(255),
    active boolean DEFAULT true,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    name character varying(255),
    organization character varying(255),
    events jsonb DEFAULT '[]'::jsonb,
    retry_attempts integer DEFAULT 3,
    timeout integer DEFAULT 10000,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_by_user integer
);


ALTER TABLE public.webhooks OWNER TO cecbs;

--
-- Name: webhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: cecbs
--

CREATE SEQUENCE public.webhooks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.webhooks_id_seq OWNER TO cecbs;

--
-- Name: webhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: cecbs
--

ALTER SEQUENCE public.webhooks_id_seq OWNED BY public.webhooks.id;


--
-- Name: _schema_migrations id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public._schema_migrations ALTER COLUMN id SET DEFAULT nextval('public._schema_migrations_id_seq'::regclass);


--
-- Name: approval_requirements id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.approval_requirements ALTER COLUMN id SET DEFAULT nextval('public.approval_requirements_id_seq'::regclass);


--
-- Name: approval_workflow_state id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.approval_workflow_state ALTER COLUMN id SET DEFAULT nextval('public.approval_workflow_state_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: audit_trail id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.audit_trail ALTER COLUMN id SET DEFAULT nextval('public.audit_trail_id_seq'::regclass);


--
-- Name: contracts id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.contracts ALTER COLUMN id SET DEFAULT nextval('public.contracts_id_seq'::regclass);


--
-- Name: customs_clearances id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.customs_clearances ALTER COLUMN id SET DEFAULT nextval('public.customs_clearances_id_seq'::regclass);


--
-- Name: customs_declarations id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.customs_declarations ALTER COLUMN id SET DEFAULT nextval('public.customs_declarations_id_seq'::regclass);


--
-- Name: customs_inspections id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.customs_inspections ALTER COLUMN id SET DEFAULT nextval('public.customs_inspections_id_seq'::regclass);


--
-- Name: customs_risk_assessments id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.customs_risk_assessments ALTER COLUMN id SET DEFAULT nextval('public.customs_risk_assessments_id_seq'::regclass);


--
-- Name: document_signatures id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.document_signatures ALTER COLUMN id SET DEFAULT nextval('public.document_signatures_id_seq'::regclass);


--
-- Name: document_verifications id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.document_verifications ALTER COLUMN id SET DEFAULT nextval('public.document_verifications_id_seq'::regclass);


--
-- Name: documents id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.documents ALTER COLUMN id SET DEFAULT nextval('public.documents_id_seq'::regclass);


--
-- Name: email_logs id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.email_logs ALTER COLUMN id SET DEFAULT nextval('public.email_logs_id_seq'::regclass);


--
-- Name: exporter_applications id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.exporter_applications ALTER COLUMN id SET DEFAULT nextval('public.exporter_applications_id_seq'::regclass);


--
-- Name: forex_allocations id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.forex_allocations ALTER COLUMN id SET DEFAULT nextval('public.forex_allocations_id_seq'::regclass);


--
-- Name: lab_test_results id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.lab_test_results ALTER COLUMN id SET DEFAULT nextval('public.lab_test_results_id_seq'::regclass);


--
-- Name: letters_of_credit id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.letters_of_credit ALTER COLUMN id SET DEFAULT nextval('public.letters_of_credit_id_seq'::regclass);


--
-- Name: notification_templates id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.notification_templates ALTER COLUMN id SET DEFAULT nextval('public.notification_templates_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: payment_confirmations id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.payment_confirmations ALTER COLUMN id SET DEFAULT nextval('public.payment_confirmations_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: post_delivery_checklist id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.post_delivery_checklist ALTER COLUMN id SET DEFAULT nextval('public.post_delivery_checklist_id_seq'::regclass);


--
-- Name: post_delivery_issues id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.post_delivery_issues ALTER COLUMN id SET DEFAULT nextval('public.post_delivery_issues_id_seq'::regclass);


--
-- Name: post_delivery_notifications id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.post_delivery_notifications ALTER COLUMN id SET DEFAULT nextval('public.post_delivery_notifications_id_seq'::regclass);


--
-- Name: post_delivery_tracking id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.post_delivery_tracking ALTER COLUMN id SET DEFAULT nextval('public.post_delivery_tracking_id_seq'::regclass);


--
-- Name: quality_certificates id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.quality_certificates ALTER COLUMN id SET DEFAULT nextval('public.quality_certificates_id_seq'::regclass);


--
-- Name: quality_inspections id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.quality_inspections ALTER COLUMN id SET DEFAULT nextval('public.quality_inspections_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: shipment_locations id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.shipment_locations ALTER COLUMN id SET DEFAULT nextval('public.shipment_locations_id_seq'::regclass);


--
-- Name: shipment_status_history id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.shipment_status_history ALTER COLUMN id SET DEFAULT nextval('public.shipment_status_history_id_seq'::regclass);


--
-- Name: shipments id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.shipments ALTER COLUMN id SET DEFAULT nextval('public.shipments_id_seq'::regclass);


--
-- Name: sms_logs id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.sms_logs ALTER COLUMN id SET DEFAULT nextval('public.sms_logs_id_seq'::regclass);


--
-- Name: sync_status id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.sync_status ALTER COLUMN id SET DEFAULT nextval('public.sync_status_id_seq'::regclass);


--
-- Name: system_alerts id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.system_alerts ALTER COLUMN id SET DEFAULT nextval('public.system_alerts_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: webhook_logs id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.webhook_logs ALTER COLUMN id SET DEFAULT nextval('public.webhook_logs_id_seq'::regclass);


--
-- Name: webhooks id; Type: DEFAULT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.webhooks ALTER COLUMN id SET DEFAULT nextval('public.webhooks_id_seq'::regclass);


--
-- Data for Name: _schema_migrations; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public._schema_migrations (id, migration_name, applied_at) FROM stdin;
1	000_initial_schema	2026-10-01 11:49:18.680446
2	001_add_exporter_applications_columns	2026-10-01 11:49:18.687258
3	002_add_applicant_credentials	2026-10-01 11:49:18.689347
4	002_add_quality_control_tables	2026-10-01 11:49:18.691304
5	002_add_shipment_id_to_customs_declarations	2026-10-01 11:49:18.693425
6	003_add_document_management_tables	2026-10-01 11:49:18.695081
7	003_expand_customs_declarations	2026-10-01 11:49:18.69961
8	004_add_customs_tables	2026-10-01 11:49:18.701466
9	004_webhooks_and_notifications	2026-10-03 09:05:54.620356
10	005_add_exit_point_to_customs_clearances	2026-10-03 09:05:54.632107
11	005_add_lc_actor_fields	2026-10-03 09:05:54.637953
12	005_add_shipment_tracking_tables	2026-10-03 09:05:54.64394
13	005_update_audit_trail_table	2026-10-03 09:05:54.649421
14	006_add_payment_enhancements	2026-10-03 09:05:54.657814
15	006_multi_party_approvals	2026-10-03 09:05:54.663751
16	007_add_forex_confirmation_fields	2026-10-03 09:05:54.68328
17	007_create_payments_table	2026-10-03 09:05:54.688913
18	008_add_documents_file_path	2026-10-03 09:05:54.694322
19	014_add_post_delivery_tracking	2026-10-03 09:05:54.700745
20	015_add_audit_logs_and_notifications	2026-10-03 09:05:54.721184
21	016_create_audit_log_table	2026-10-03 09:05:54.734552
22	017_create_blockchain_sync_tables	2026-10-03 09:05:54.741631
23	018_update_users_table_schema	2026-10-03 09:05:54.748447
\.


--
-- Data for Name: approval_requirements; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.approval_requirements (id, document_type, entity_type, min_approvers, required_roles, approval_order, description, active, created_at, updated_at) FROM stdin;
1	COMMERCIAL_INVOICE	LC	2	{bank_officer,senior_bank_officer}	sequential	Commercial invoices require junior and senior bank officer approval	t	2026-10-01 10:25:02.791084	2026-10-01 10:25:02.791084
2	BILL_OF_LADING	LC	2	{bank_officer,senior_bank_officer}	sequential	Bill of lading requires junior and senior bank officer approval	t	2026-10-01 10:25:02.791084	2026-10-01 10:25:02.791084
3	CERTIFICATE_OF_ORIGIN	LC	2	{ecta_inspector,ecta_supervisor}	sequential	Certificate of origin requires inspector and supervisor approval	t	2026-10-01 10:25:02.791084	2026-10-01 10:25:02.791084
4	QUALITY_CERTIFICATE	LC	2	{ecta_inspector,ecta_supervisor}	sequential	Quality certificate requires inspector and supervisor approval	t	2026-10-01 10:25:02.791084	2026-10-01 10:25:02.791084
5	INSURANCE_CERTIFICATE	LC	1	{bank_officer}	parallel	Insurance certificate requires single bank officer approval	t	2026-10-01 10:25:02.791084	2026-10-01 10:25:02.791084
6	PACKING_LIST	LC	1	{bank_officer}	parallel	Packing list requires single bank officer approval	t	2026-10-01 10:25:02.791084	2026-10-01 10:25:02.791084
7	SALES_CONTRACT	CONTRACT	2	{ecta_inspector,ecta_supervisor}	sequential	Sales contracts require inspector and supervisor approval	t	2026-10-01 10:25:02.791084	2026-10-01 10:25:02.791084
8	EXPORT_LICENSE	CONTRACT	2	{ecta_inspector,ecta_supervisor}	sequential	Export licenses require inspector and supervisor approval	t	2026-10-01 10:25:02.791084	2026-10-01 10:25:02.791084
9	CUSTOMS_DECLARATION	CUSTOMS_DECLARATION	2	{customs_officer,senior_customs_officer}	sequential	Customs declarations require officer and senior officer approval	t	2026-10-01 10:25:02.791084	2026-10-01 10:25:02.791084
10	DUTY_ASSESSMENT	CUSTOMS_DECLARATION	2	{customs_officer,senior_customs_officer}	sequential	Duty assessments require officer and senior officer approval	t	2026-10-01 10:25:02.791084	2026-10-01 10:25:02.791084
11	SHIPPING_MANIFEST	SHIPMENT	1	{shipping_agent}	parallel	Shipping manifest requires shipping agent approval	t	2026-10-01 10:25:02.791084	2026-10-01 10:25:02.791084
12	CONTAINER_SEAL	SHIPMENT	2	{shipping_agent,customs_officer}	parallel	Container sealing requires shipping agent and customs officer	t	2026-10-01 10:25:02.791084	2026-10-01 10:25:02.791084
\.


--
-- Data for Name: approval_workflow_state; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.approval_workflow_state (id, entity_type, entity_id, current_state, required_approvals, received_approvals, status, created_at, document_id, document_type, current_approvals, approval_status, approved_by, rejected_by, rejection_reason, completed_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.audit_log (id, entity_type, entity_id, action, user_id, details, created_at, username, ip_address, user_agent) FROM stdin;
1	user	1	LOGIN	1	{"username": "admin"}	2026-10-01 11:47:54.649663	\N	::1	curl/8.22.0
2	user	1	LOGIN	1	{"username": "admin"}	2026-10-01 11:48:14.73391	\N	::1	curl/8.22.0
3	user	1	LOGIN	1	{"username": "admin"}	2026-10-01 11:48:52.676698	\N	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36
4	user	1	LOGIN	1	{"username": "admin"}	2026-10-01 12:07:31.082172	\N	::1	curl/8.22.0
5	user	1	LOGIN	1	{"username": "admin"}	2026-10-01 12:09:42.650784	\N	::1	curl/8.22.0
6	user	2	LOGIN	2	{"username": "exporter1"}	2026-10-01 12:09:42.711217	\N	::1	curl/8.22.0
7	user	1	LOGIN	1	{"username": "admin"}	2026-10-01 12:10:41.281702	\N	::1	curl/8.22.0
8	user	2	LOGIN	2	{"username": "exporter1"}	2026-10-01 12:10:41.340415	\N	::1	curl/8.22.0
9	user	1	LOGIN	1	{"username": "admin"}	2026-10-01 12:11:54.822362	\N	::1	curl/8.22.0
10	user	2	LOGIN	2	{"username": "exporter1"}	2026-10-01 12:11:54.902281	\N	::1	curl/8.22.0
11	user	1	LOGIN	1	{"username": "admin"}	2026-10-01 12:18:02.158616	\N	::1	curl/8.22.0
12	user	2	LOGIN	2	{"username": "exporter1"}	2026-10-01 12:18:02.216446	\N	::1	curl/8.22.0
13	user	1	LOGIN	1	{"username": "admin"}	2026-10-01 12:49:04.60483	\N	::1	curl/8.22.0
14	user	2	LOGIN	2	{"username": "exporter1"}	2026-10-01 12:49:04.661591	\N	::1	curl/8.22.0
15	user	1	LOGIN	1	{"username": "admin"}	2026-10-01 12:50:33.387411	\N	::1	curl/8.22.0
16	user	2	LOGIN	2	{"username": "exporter1"}	2026-10-01 12:50:33.501498	\N	::1	curl/8.22.0
17	user	1	LOGIN	1	{"username": "admin"}	2026-10-01 15:47:58.009547	\N	::1	curl/8.22.0
18	user	2	LOGIN	2	{"username": "exporter1"}	2026-10-01 15:47:58.137182	\N	::1	curl/8.22.0
19	user	1	LOGIN	1	{"username": "admin"}	2026-10-01 15:51:37.784948	\N	::1	curl/8.22.0
20	user	2	LOGIN	2	{"username": "exporter1"}	2026-10-01 15:51:37.898874	\N	::1	curl/8.22.0
21	user	1	LOGIN	1	{"username": "admin"}	2026-10-01 16:05:14.883997	\N	::1	curl/8.22.0
22	user	2	LOGIN	2	{"username": "exporter1"}	2026-10-01 16:05:14.998307	\N	::1	curl/8.22.0
23	user	1	LOGIN	1	{"username": "admin"}	2026-10-01 16:26:00.234176	\N	::1	curl/8.22.0
24	user	2	LOGIN	2	{"username": "exporter1"}	2026-10-01 16:26:00.364876	\N	::1	curl/8.22.0
25	user	1	LOGIN	1	{"username": "admin"}	2026-10-01 20:05:47.99372	\N	::1	curl/8.22.0
26	user	2	LOGIN	2	{"username": "exporter1"}	2026-10-01 20:05:48.09977	\N	::1	curl/8.22.0
27	user	1	LOGIN	1	{"username": "admin"}	2026-10-01 20:06:52.298702	\N	::1	curl/8.22.0
28	user	2	LOGIN	2	{"username": "exporter1"}	2026-10-01 20:06:52.4047	\N	::1	curl/8.22.0
29	user	1	LOGIN	1	{"username": "admin"}	2026-10-01 20:12:00.193307	\N	::1	curl/8.22.0
30	user	2	LOGIN	2	{"username": "exporter1"}	2026-10-01 20:12:00.324793	\N	::1	curl/8.22.0
31	user	1	LOGIN	1	{"username": "admin"}	2026-10-01 20:22:24.793864	\N	::1	curl/8.22.0
32	user	2	LOGIN	2	{"username": "exporter1"}	2026-10-01 20:22:24.896453	\N	::1	curl/8.22.0
33	user	1	LOGIN	1	{"username": "admin"}	2026-10-01 20:23:24.947077	\N	::1	curl/8.22.0
34	user	2	LOGIN	2	{"username": "exporter1"}	2026-10-01 20:23:25.057324	\N	::1	curl/8.22.0
35	user	1	LOGIN	1	{"username": "admin"}	2026-10-01 20:23:40.391617	\N	::1	curl/8.22.0
36	user	2	LOGIN	2	{"username": "exporter1"}	2026-10-01 20:23:40.498947	\N	::1	curl/8.22.0
37	user	1	LOGIN	1	{"username": "admin"}	2026-10-03 08:07:46.314249	\N	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36
38	user	1	LOGIN	1	{"username": "admin"}	2026-10-03 09:20:09.846021	\N	::1	curl/8.22.0
39	user	4	LOGIN	4	{"username": "bankAdmin"}	2026-10-03 09:23:28.932838	\N	::1	curl/8.22.0
40	user	4	LOGIN	4	{"username": "bankAdmin"}	2026-10-03 09:27:36.638176	\N	::1	curl/8.22.0
41	user	4	LOGIN	4	{"username": "bankAdmin"}	2026-10-03 09:30:13.552709	\N	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36
42	user	1	LOGIN	1	{"username": "admin"}	2026-10-05 10:21:49.905656	\N	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
43	user	2	LOGIN	2	{"username": "exporter1"}	2026-10-05 10:22:26.940816	\N	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
44	user	1	LOGIN	1	{"username": "admin"}	2026-10-05 11:01:04.612257	\N	::1	curl/8.22.0
45	user	1	LOGIN	1	{"username": "admin"}	2026-10-05 11:01:25.058603	\N	::1	curl/8.22.0
46	user	1	LOGIN	1	{"username": "admin"}	2026-10-05 11:10:00.067264	\N	::1	curl/8.22.0
47	user	1	LOGIN	1	{"username": "admin"}	2026-10-05 11:26:20.952572	\N	::1	curl/8.22.0
48	user	1	LOGIN	1	{"username": "admin"}	2026-10-05 11:44:50.352125	\N	::1	curl/8.22.0
49	user	1	LOGIN	1	{"username": "admin"}	2026-10-05 19:46:51.510054	\N	::1	curl/8.22.0
50	user	1	LOGIN	1	{"username": "admin"}	2026-10-06 07:17:24.089903	\N	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
51	user	4	LOGIN	4	{"username": "bankAdmin"}	2026-10-06 10:33:34.685402	\N	::1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.audit_logs (id, action, entity_type, entity_id, user_id, changes, "timestamp", event_type, event_category, severity, username, user_role, organization, description, resource_type, resource_id, ip_address, user_agent, endpoint, http_method, http_status, old_value, new_value, blockchain_tx_id, blockchain_block_number, blockchain_timestamp, metadata, tags) FROM stdin;
\.


--
-- Data for Name: audit_trail; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.audit_trail (id, entity_type, entity_id, action, user_id, old_value, new_value, "timestamp", ip_address, performed_by_org, performed_by, organization, changes, created_at, blockchain_tx_id, reason, metadata) FROM stdin;
\.


--
-- Data for Name: blockchain_contracts; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.blockchain_contracts (contract_id, exporter_id, buyer_id, contract_type, quantity, price_per_kg, total_value, payment_terms, status, created_at, synced_from, synced_at, raw_data) FROM stdin;
\.


--
-- Data for Name: blockchain_customs; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.blockchain_customs (clearance_id, shipment_id, declaration_number, clearance_status, duty_paid, clearance_date, exit_point, created_at, synced_from, synced_at, raw_data) FROM stdin;
\.


--
-- Data for Name: blockchain_documents; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.blockchain_documents (document_id, shipment_id, document_type, issuer, status, ipfs_hash, file_path, verified, verification_date, created_at, synced_from, synced_at, raw_data) FROM stdin;
\.


--
-- Data for Name: blockchain_payments; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.blockchain_payments (payment_id, shipment_id, lc_number, amount, currency, status, payment_date, bank_reference, created_at, synced_from, synced_at, raw_data) FROM stdin;
\.


--
-- Data for Name: blockchain_shipments; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.blockchain_shipments (shipment_id, contract_id, exporter_id, buyer_id, origin, quantity, grade, ico_number, ecx_lot_number, ecx_lots, documents, status, channel, forex_rate, value_usd, eudr_compliant, packaging_type, bag_weight, total_bags, net_weight, gross_weight, insurance_policy, insurance_company, insurance_amount, transport_mode, shipping_line, bill_of_lading_no, vessel_name, container_number, departure_port, destination_port, estimated_arrival, actual_arrival, created_at, updated_at, synced_from, synced_at, raw_data) FROM stdin;
\.


--
-- Data for Name: border_crossings; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.border_crossings (crossing_id, shipment_id, contract_id, exporter_id, border_post, border_country, crossing_type, transit_country, final_destination, exit_permit_number, exit_permit_issued, exit_permit_expiry, customs_declaration, transport_mode, vehicle_number, driver_name, driver_license, seal_number, cargo_weight, number_of_bags, container_numbers, status, departure_date, crossing_date, arrival_date, transit_duration, ethiopian_customs_officer, ethiopian_clearance_date, ethiopian_clearance_ref, border_customs_officer, border_clearance_date, border_clearance_ref, border_stamp_url, last_known_location, last_location_update, tracking_number, checkpoints_passed, delay_reported, delay_reason, delay_duration, issues_encountered, verified_by, verified_by_msp, verification_date, compliance_status, compliance_notes, recorded_by, recorded_by_msp, last_updated_by, last_updated_by_msp, comments, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: contracts; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.contracts (id, contract_id, exporter_id, buyer_id, quantity, price_per_kg, total_value, payment_terms, delivery_terms, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: customs_clearances; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.customs_clearances (id, clearance_id, shipment_id, declaration_id, clearance_date, exit_point, status, notes, created_at, clearance_number, cleared_by, cleared_date, duty_amount, tax_amount, remarks, updated_at) FROM stdin;
\.


--
-- Data for Name: customs_declarations; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.customs_declarations (id, declaration_id, shipment_id, declaration_number, declared_value, duty_amount, status, submitted_date, cleared_date, created_at, exporter_id, declaration_type, hs_code, quantity, currency, destination, port_of_exit, eudr_compliant, additional_notes, customs_officer, inspection_required, updated_at) FROM stdin;
\.


--
-- Data for Name: customs_inspections; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.customs_inspections (id, inspection_id, shipment_id, clearance_id, inspection_type, inspection_date, inspector_name, inspection_result, findings, created_at) FROM stdin;
\.


--
-- Data for Name: customs_risk_assessments; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.customs_risk_assessments (id, assessment_id, shipment_id, exporter_id, risk_factors, risk_level, inspection_required, assessed_by, assessment_date, remarks, created_at) FROM stdin;
\.


--
-- Data for Name: document_signatures; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.document_signatures (id, document_id, signature_type, signed_by, signed_at, approval_level, approval_order, signed_by_role, approval_status, approval_notes, requires_further_approval, created_at) FROM stdin;
\.


--
-- Data for Name: document_verifications; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.document_verifications (id, document_id, verified_by, verification_date, status, notes, verification_id, verified_by_org, verified, remarks, created_at) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.documents (id, document_id, shipment_id, document_type, document_name, file_hash, ipfs_hash, uploaded_by, uploaded_at, status, verified, contract_id, exporter_id, file_name, file_size, mime_type, ipfs_cid, upload_date, file_path) FROM stdin;
\.


--
-- Data for Name: email_logs; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.email_logs (id, recipient, subject, body, status, sent_at, delivered_at, opened_at, clicked_at, error) FROM stdin;
\.


--
-- Data for Name: export_proceeds_repatriation; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.export_proceeds_repatriation (repatriation_id, payment_id, contract_id, shipment_id, exporter_id, export_amount, currency, required_retention, required_conversion, retention_percentage, conversion_percentage, repatriated_amount, converted_amount, converted_amount_birr, exchange_rate, fcy_account_number, fcy_bank, fcy_bank_bic, status, compliance_deadline, shipment_date, repatriation_date, compliance_date, days_remaining, is_overdue, verified_by, verified_by_msp, verification_date, verification_ref, verification_notes, penalty_amount, penalty_currency, waiver_requested, waiver_approved, waiver_reason, waiver_date, swift_references, bank_certificate, recorded_by, recorded_by_msp, last_updated_by, last_updated_by_msp, comments, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: exporter_applications; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.exporter_applications (id, company_name, tin, license_number, contact_person, email, phone, address, status, submitted_date, reviewed_date, reviewed_by, rejection_reason, created_at, updated_at, temp_username, temp_password, temp_credentials_sent, account_created, license_issued_date, license_expiry_date, digital_signature, verification_code, bank_branch, bank_branch_code, documents, ecta_license_number, laboratory_certificate_number, exporter_type) FROM stdin;
\.


--
-- Data for Name: forex_allocations; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.forex_allocations (id, allocation_id, shipment_id, lc_number, amount_usd, exchange_rate, amount_local, allocation_date, status, approved_by, created_at, contract_id, exporter_id, amount_etb, approved_by_name, utilized_amount, remarks, updated_at, confirmed_by, confirmed_at) FROM stdin;
\.


--
-- Data for Name: lab_test_results; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.lab_test_results (id, test_id, inspection_id, test_type, test_date, result, details, tested_by, created_at) FROM stdin;
\.


--
-- Data for Name: lc_discrepancies; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.lc_discrepancies (discrepancy_id, lc_id, document, issue, reported_date, resolved_date, resolution, status, reported_by, reported_by_msp, resolved_by, resolved_by_msp, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: letters_of_credit; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.letters_of_credit (id, lc_number, shipment_id, issuing_bank, advising_bank, beneficiary, applicant, amount, currency, issue_date, expiry_date, status, created_at, updated_at, approved_by, approved_by_msp, issued_by, issued_by_msp, last_updated_by, last_updated_by_msp) FROM stdin;
\.


--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.notification_preferences (user_id, email_enabled, sms_enabled, webhook_enabled, events, phone, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_templates; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.notification_templates (id, template_code, template_name, description, subject_template, body_template, sms_template, required_variables, default_channels, default_priority, category, is_active, created_at, updated_at) FROM stdin;
1	CONTRACT_APPROVED	Contract Approval Notification	\N	Contract {{contractId}} Approved	Dear {{exporterName}},\\n\\nYour contract {{contractId}} has been approved by ECTA.\\n\\nContract Details:\\n- Buyer: {{buyerName}}\\n- Quantity: {{quantity}} bags\\n- Value: {{value}} {{currency}}\\n\\nYou can now proceed with shipment preparation.\\n\\nBest regards,\\nECTA	Contract {{contractId}} approved. Proceed with shipment preparation.	{contractId,exporterName,buyerName,quantity,value,currency}	{EMAIL,SMS,IN_APP}	NORMAL	OPERATIONAL	t	2026-10-03 07:45:01.273421	2026-10-03 07:45:01.273421
2	SHIPMENT_DELIVERED	Shipment Delivery Notification	\N	Shipment {{shipmentId}} Delivered	Dear {{exporterName}},\\n\\nYour shipment {{shipmentId}} has been successfully delivered to the destination.\\n\\nDelivery Details:\\n- Destination: {{destination}}\\n- Delivery Date: {{deliveryDate}}\\n\\nPost-delivery workflow initiated:\\n✓ Payment settlement\\n✓ Forex repatriation\\n✓ LC settlement\\n✓ ECTA final audit\\n\\nBest regards,\\nCECBS System	Shipment {{shipmentId}} delivered to {{destination}}.	{shipmentId,exporterName,destination,deliveryDate}	{EMAIL,IN_APP}	NORMAL	OPERATIONAL	t	2026-10-03 07:45:01.273421	2026-10-03 07:45:01.273421
3	PAYMENT_OVERDUE	Payment Overdue Alert	\N	URGENT: Payment Overdue for Shipment {{shipmentId}}	Dear {{exporterName}},\\n\\nPayment for shipment {{shipmentId}} is overdue.\\n\\nDetails:\\n- Due Date: {{dueDate}}\\n- Days Overdue: {{daysOverdue}}\\n- Amount: {{amount}} {{currency}}\\n\\nPlease take immediate action to resolve this issue.\\n\\nBest regards,\\nNBE Compliance Team	URGENT: Payment for {{shipmentId}} is {{daysOverdue}} days overdue.	{shipmentId,exporterName,dueDate,daysOverdue,amount,currency}	{EMAIL,SMS,IN_APP}	NORMAL	FINANCIAL	t	2026-10-03 07:45:01.273421	2026-10-03 07:45:01.273421
4	CUSTOMS_CLEARANCE_APPROVED	Customs Clearance Approved	\N	Customs Clearance Approved for {{shipmentId}}	Dear {{exporterName}},\\n\\nCustoms clearance has been approved for shipment {{shipmentId}}.\\n\\nClearance Details:\\n- Clearance Number: {{clearanceNumber}}\\n- Approved By: {{approvedBy}}\\n- Approved Date: {{approvedDate}}\\n\\nYour shipment can now proceed to the next stage.\\n\\nBest regards,\\nEthiopian Customs Authority	Customs cleared: {{shipmentId}}	{shipmentId,exporterName,clearanceNumber,approvedBy,approvedDate}	{EMAIL,IN_APP}	NORMAL	COMPLIANCE	t	2026-10-03 07:45:01.273421	2026-10-03 07:45:01.273421
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.notifications (id, user_id, title, message, type, read, created_at, recipient_email, recipient_phone, recipient_name, organization, notification_type, priority, category, channels, email_subject, email_html, email_attachments, sms_message, push_data, in_app_read, in_app_read_at, webhook_url, webhook_payload, webhook_headers, action_url, action_label, resource_type, resource_id, contract_id, shipment_id, status, email_sent, email_sent_at, email_error, sms_sent, sms_sent_at, sms_error, webhook_sent, webhook_sent_at, webhook_response_status, webhook_error, retry_count, max_retries, next_retry_at, scheduled_for, expires_at, metadata, tags, updated_at, sent_at) FROM stdin;
\.


--
-- Data for Name: payment_confirmations; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.payment_confirmations (id, confirmation_id, payment_id, confirmed_by, confirmed_by_org, confirmation_date, confirmation_type, reference_number, remarks, created_at) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.payments (id, payment_id, lc_number, shipment_id, amount, currency, payment_date, status, notes, created_at, contract_id, exporter_id, payment_method) FROM stdin;
\.


--
-- Data for Name: post_delivery_checklist; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.post_delivery_checklist (id, shipment_id, item_type, description, display_order, completed, completed_at, notes) FROM stdin;
\.


--
-- Data for Name: post_delivery_issues; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.post_delivery_issues (id, shipment_id, issue_type, severity, message, resolved, resolved_at, resolved_by, resolution_notes, created_at) FROM stdin;
\.


--
-- Data for Name: post_delivery_notifications; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.post_delivery_notifications (id, shipment_id, notification_type, recipient_role, message, sent, sent_at, read, read_at, created_at) FROM stdin;
\.


--
-- Data for Name: post_delivery_tracking; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.post_delivery_tracking (id, tracking_id, shipment_id, arrival_date, warehouse_location, quality_recheck_status, status, notes, created_at, contract_id, exporter_id, delivery_date, payment_received, payment_received_date, payment_amount, payment_currency, swift_reference, forex_repatriated, forex_repatriation_date, forex_amount, forex_rate, lc_used, lc_settled, lc_settlement_date, lc_reference, ecta_audit_completed, ecta_audit_date, ecta_audit_result, ecta_audit_notes, contract_closed, contract_closure_date, overall_status, completion_percentage, expected_completion_date, created_by, updated_by, updated_at) FROM stdin;
\.


--
-- Data for Name: pre_shipment_inspections; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.pre_shipment_inspections (inspection_id, contract_id, shipment_id, exporter_id, inspection_agency, inspector_name, inspector_license, requested_by, request_date, inspection_date, inspection_location, contract_quantity, contract_grade, contract_type, packaging_type, inspected_quantity, quantity_variance, quantity_acceptable, actual_grade, cupping_score, defects_count, moisture_content, bean_size, quality_acceptable, bags_inspected, packaging_condition, packaging_acceptable, status, overall_result, inspection_notes, recommendations, certificate_number, certificate_issued, certificate_expiry, certificate_url, samples_taken, sample_ids, lab_test_required, lab_test_completed, lab_test_results, issues_found, corrective_actions, re_inspection_required, approved_by, approved_by_msp, approval_date, rejected_by, rejected_by_msp, rejection_reason, recorded_by, recorded_by_msp, last_updated_by, last_updated_by_msp, comments, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: quality_certificates; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.quality_certificates (id, certificate_number, inspection_id, exporter_id, coffee_type, quantity, grade, issue_date, expiry_date, issued_by, certificate_hash, ipfs_cid, created_at) FROM stdin;
\.


--
-- Data for Name: quality_inspections; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.quality_inspections (id, shipment_id, inspector_id, inspection_date, grade, moisture_content, defect_count, cup_quality, status, notes, created_at, inspection_id, exporter_id, contract_id, coffee_type, quantity, sample_size, requested_date, inspector_name, screen_size, passed, certification_number, remarks, updated_at) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.roles (id, name, description, permissions, created_at) FROM stdin;
\.


--
-- Data for Name: shipment_locations; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.shipment_locations (id, shipment_id, latitude, longitude, location_name, recorded_at, vessel_name, container_number, created_at) FROM stdin;
\.


--
-- Data for Name: shipment_status_history; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.shipment_status_history (id, shipment_id, status, changed_by, changed_at, notes, location, updated_by, update_date, remarks) FROM stdin;
\.


--
-- Data for Name: shipments; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.shipments (id, shipment_id, contract_id, exporter_id, buyer_id, origin, destination, quantity, grade, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sms_logs; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.sms_logs (id, phone, message, status, provider, sent_at, delivered_at, error) FROM stdin;
\.


--
-- Data for Name: sync_status; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.sync_status (id, couch_instance, database_name, last_sync, last_seq, documents_synced, status, error_message) FROM stdin;
1	ECTA	coffeechannel_	2026-10-06 13:05:44.627511	\N	3	success	\N
2	ECTA	coffeechannel__lifecycle	2026-10-06 13:05:44.63479	\N	5	success	\N
3	ECTA	coffeechannel__lifecycle$$h_implicit_org_$banks$m$s$p	2026-10-06 13:05:44.644851	\N	144	success	\N
4	ECTA	coffeechannel__lifecycle$$h_implicit_org_$customs$m$s$p	2026-10-06 13:05:44.652923	\N	144	success	\N
5	ECTA	coffeechannel__lifecycle$$h_implicit_org_$e$c$t$a$m$s$p	2026-10-06 13:05:44.6623	\N	144	success	\N
6	ECTA	coffeechannel__lifecycle$$h_implicit_org_$e$c$x$m$s$p	2026-10-06 13:05:44.671295	\N	144	success	\N
7	ECTA	coffeechannel__lifecycle$$h_implicit_org_$n$b$e$m$s$p	2026-10-06 13:05:44.681442	\N	144	success	\N
8	ECTA	coffeechannel__lifecycle$$h_implicit_org_$shipping$m$s$p	2026-10-06 13:05:44.688412	\N	144	success	\N
9	ECTA	coffeechannel__lifecycle$$p_implicit_org_$e$c$t$a$m$s$p	2026-10-06 13:05:44.697606	\N	144	success	\N
21610	ECTA	coffeechannel_coffee	2026-10-06 13:05:44.701149	\N	1	success	\N
10	ECTA	coffeechannel_lscc	2026-10-06 13:05:44.704507	\N	0	success	\N
11	ECX	coffeechannel_	2026-10-06 13:05:44.710805	\N	3	success	\N
12	ECX	coffeechannel__lifecycle	2026-10-06 13:05:44.71445	\N	5	success	\N
13	ECX	coffeechannel__lifecycle$$h_implicit_org_$banks$m$s$p	2026-10-06 13:05:44.723928	\N	144	success	\N
14	ECX	coffeechannel__lifecycle$$h_implicit_org_$customs$m$s$p	2026-10-06 13:05:44.7331	\N	144	success	\N
15	ECX	coffeechannel__lifecycle$$h_implicit_org_$e$c$t$a$m$s$p	2026-10-06 13:05:44.742075	\N	144	success	\N
16	ECX	coffeechannel__lifecycle$$h_implicit_org_$e$c$x$m$s$p	2026-10-06 13:05:44.7527	\N	144	success	\N
17	ECX	coffeechannel__lifecycle$$h_implicit_org_$n$b$e$m$s$p	2026-10-06 13:05:44.763521	\N	144	success	\N
18	ECX	coffeechannel__lifecycle$$h_implicit_org_$shipping$m$s$p	2026-10-06 13:05:44.772179	\N	144	success	\N
19	ECX	coffeechannel__lifecycle$$p_implicit_org_$e$c$x$m$s$p	2026-10-06 13:05:44.781611	\N	144	success	\N
21621	ECX	coffeechannel_coffee	2026-10-06 13:05:44.785502	\N	1	success	\N
20	ECX	coffeechannel_lscc	2026-10-06 13:05:44.789022	\N	0	success	\N
21	Banks	coffeechannel_	2026-10-06 13:05:44.796068	\N	3	success	\N
22	Banks	coffeechannel__lifecycle	2026-10-06 13:05:44.800085	\N	5	success	\N
23	Banks	coffeechannel__lifecycle$$h_implicit_org_$banks$m$s$p	2026-10-06 13:05:44.810639	\N	144	success	\N
24	Banks	coffeechannel__lifecycle$$h_implicit_org_$customs$m$s$p	2026-10-06 13:05:44.820827	\N	144	success	\N
25	Banks	coffeechannel__lifecycle$$h_implicit_org_$e$c$t$a$m$s$p	2026-10-06 13:05:44.831462	\N	144	success	\N
26	Banks	coffeechannel__lifecycle$$h_implicit_org_$e$c$x$m$s$p	2026-10-06 13:05:44.841163	\N	144	success	\N
27	Banks	coffeechannel__lifecycle$$h_implicit_org_$n$b$e$m$s$p	2026-10-06 13:05:44.85061	\N	144	success	\N
28	Banks	coffeechannel__lifecycle$$h_implicit_org_$shipping$m$s$p	2026-10-06 13:05:44.861548	\N	144	success	\N
29	Banks	coffeechannel__lifecycle$$p_implicit_org_$banks$m$s$p	2026-10-06 13:05:44.872142	\N	144	success	\N
22066	Banks	coffeechannel_coffee	2026-10-06 13:05:44.877736	\N	1	success	\N
30	Banks	coffeechannel_lscc	2026-10-06 13:05:44.881893	\N	0	success	\N
31	NBE	coffeechannel_	2026-10-06 13:05:44.889374	\N	3	success	\N
32	NBE	coffeechannel__lifecycle	2026-10-06 13:05:44.89321	\N	5	success	\N
33	NBE	coffeechannel__lifecycle$$h_implicit_org_$banks$m$s$p	2026-10-06 13:05:44.903678	\N	144	success	\N
34	NBE	coffeechannel__lifecycle$$h_implicit_org_$customs$m$s$p	2026-10-06 13:05:44.913858	\N	144	success	\N
35	NBE	coffeechannel__lifecycle$$h_implicit_org_$e$c$t$a$m$s$p	2026-10-06 13:05:44.922482	\N	144	success	\N
36	NBE	coffeechannel__lifecycle$$h_implicit_org_$e$c$x$m$s$p	2026-10-06 13:05:44.932572	\N	144	success	\N
37	NBE	coffeechannel__lifecycle$$h_implicit_org_$n$b$e$m$s$p	2026-10-06 13:05:44.941733	\N	144	success	\N
38	NBE	coffeechannel__lifecycle$$h_implicit_org_$shipping$m$s$p	2026-10-06 13:05:44.950771	\N	144	success	\N
39	NBE	coffeechannel__lifecycle$$p_implicit_org_$n$b$e$m$s$p	2026-10-06 13:05:44.960051	\N	144	success	\N
22077	NBE	coffeechannel_coffee	2026-10-06 13:05:44.964048	\N	1	success	\N
40	NBE	coffeechannel_lscc	2026-10-06 13:05:44.967297	\N	0	success	\N
41	Customs	coffeechannel_	2026-10-06 13:05:44.974194	\N	3	success	\N
42	Customs	coffeechannel__lifecycle	2026-10-06 13:05:44.978021	\N	5	success	\N
43	Customs	coffeechannel__lifecycle$$h_implicit_org_$banks$m$s$p	2026-10-06 13:05:44.986013	\N	144	success	\N
44	Customs	coffeechannel__lifecycle$$h_implicit_org_$customs$m$s$p	2026-10-06 13:05:44.994325	\N	144	success	\N
45	Customs	coffeechannel__lifecycle$$h_implicit_org_$e$c$t$a$m$s$p	2026-10-06 13:05:45.001284	\N	144	success	\N
46	Customs	coffeechannel__lifecycle$$h_implicit_org_$e$c$x$m$s$p	2026-10-06 13:05:45.007909	\N	144	success	\N
47	Customs	coffeechannel__lifecycle$$h_implicit_org_$n$b$e$m$s$p	2026-10-06 13:05:45.015871	\N	144	success	\N
48	Customs	coffeechannel__lifecycle$$h_implicit_org_$shipping$m$s$p	2026-10-06 13:05:45.02312	\N	144	success	\N
49	Customs	coffeechannel__lifecycle$$p_implicit_org_$customs$m$s$p	2026-10-06 13:05:45.030864	\N	144	success	\N
22152	Customs	coffeechannel_coffee	2026-10-06 13:05:45.034158	\N	1	success	\N
50	Customs	coffeechannel_lscc	2026-10-06 13:05:45.037241	\N	0	success	\N
51	Shipping	coffeechannel_	2026-10-06 13:05:45.044104	\N	3	success	\N
52	Shipping	coffeechannel__lifecycle	2026-10-06 13:05:45.048181	\N	5	success	\N
53	Shipping	coffeechannel__lifecycle$$h_implicit_org_$banks$m$s$p	2026-10-06 13:05:45.058613	\N	144	success	\N
54	Shipping	coffeechannel__lifecycle$$h_implicit_org_$customs$m$s$p	2026-10-06 13:05:45.0694	\N	144	success	\N
55	Shipping	coffeechannel__lifecycle$$h_implicit_org_$e$c$t$a$m$s$p	2026-10-06 13:05:45.079442	\N	144	success	\N
56	Shipping	coffeechannel__lifecycle$$h_implicit_org_$e$c$x$m$s$p	2026-10-06 13:05:45.090227	\N	144	success	\N
57	Shipping	coffeechannel__lifecycle$$h_implicit_org_$n$b$e$m$s$p	2026-10-06 13:05:45.100645	\N	144	success	\N
58	Shipping	coffeechannel__lifecycle$$h_implicit_org_$shipping$m$s$p	2026-10-06 13:05:45.110281	\N	144	success	\N
59	Shipping	coffeechannel__lifecycle$$p_implicit_org_$shipping$m$s$p	2026-10-06 13:05:45.120073	\N	144	success	\N
22163	Shipping	coffeechannel_coffee	2026-10-06 13:05:45.123632	\N	1	success	\N
60	Shipping	coffeechannel_lscc	2026-10-06 13:05:45.126967	\N	0	success	\N
\.


--
-- Data for Name: system_alerts; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.system_alerts (id, alert_type, severity, title, message, metadata, resolved, resolved_at, resolved_by, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.users (id, username, password_hash, email, role, organization, status, created_at, updated_at, full_name, exporter_id, ecta_license, phone, bank_name, bank_account_number, bank_branch, bank_branch_code, permissions, last_login, is_active) FROM stdin;
1	admin	$2b$10$TFSZX/qGFSCfTkvSFmLIj.rwxdXFMUnypOXOZRtTkbyPW2i9UHS22	admin@cecbs.et	ADMIN	ADMIN	active	2026-10-01 11:33:40.870719	2026-10-01 11:33:40.870719	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t
3	ecta_admin	$2b$10$.IgJFl.jOoPp8mssJgdM7.rs7hk5SeDz6rjzj8hkBckQE/fcmnojO	admin@ecta.gov.et	ECTA	ECTA	active	2026-10-01 11:33:40.883341	2026-10-01 11:33:40.883341	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t
2	exporter1	$2b$10$.IgJFl.jOoPp8mssJgdM7.rs7hk5SeDz6rjzj8hkBckQE/fcmnojO	exporter@test.com	EXPORTER	EXP001	active	2026-10-01 11:33:40.879802	2026-10-01 11:33:40.879802	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t
4	bankAdmin	$2b$10$S0j5cur9ALOe5wG3Y69yUOMTeNMnKMf9Z.1kNCaph.KM2bkLTbLoG	admin@bank.gov.et	BANKS	BANKS	active	2026-10-03 09:13:30.903529	2026-10-03 09:13:30.903529	Bank	\N	\N	0926108320	\N	\N	\N	\N	[]	\N	t
5	shippingAdmin	$2b$10$fFF4x1fhwozf9fwPufYIg.fEvPE.Y5zIfcJUTk/4vlkNXgtCsm5bm	admin@shipping.gov.et	SHIPPING	SHIPPING	active	2026-10-06 07:19:29.405781	2026-10-06 07:19:29.405781	Shipping	\N	\N	0926108320	\N	\N	\N	\N	[]	\N	t
6	nbeAdmin	$2b$10$VXcgDzyl2V0XOTrMGGsWJuEHzwSmf0SxFm1HqyXUy3NZPmYrDKGgS	admin@nbe.gov.et	NBE	NBE	active	2026-10-06 07:21:39.393483	2026-10-06 07:21:39.393483	National bank	\N	\N	0926108320	\N	\N	\N	\N	[]	\N	t
\.


--
-- Data for Name: webhook_logs; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.webhook_logs (id, webhook_id, event, status, status_code, error, delivered_at) FROM stdin;
\.


--
-- Data for Name: webhooks; Type: TABLE DATA; Schema: public; Owner: cecbs
--

COPY public.webhooks (id, webhook_id, url, event_type, secret, active, created_by, created_at, name, organization, events, retry_attempts, timeout, updated_at, created_by_user) FROM stdin;
\.


--
-- Name: _schema_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public._schema_migrations_id_seq', 23, true);


--
-- Name: approval_requirements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.approval_requirements_id_seq', 48, true);


--
-- Name: approval_workflow_state_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.approval_workflow_state_id_seq', 1, false);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 51, true);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 1, false);


--
-- Name: audit_trail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.audit_trail_id_seq', 1, false);


--
-- Name: contracts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.contracts_id_seq', 1, false);


--
-- Name: customs_clearances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.customs_clearances_id_seq', 1, false);


--
-- Name: customs_declarations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.customs_declarations_id_seq', 1, false);


--
-- Name: customs_inspections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.customs_inspections_id_seq', 1, false);


--
-- Name: customs_risk_assessments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.customs_risk_assessments_id_seq', 1, false);


--
-- Name: document_signatures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.document_signatures_id_seq', 1, false);


--
-- Name: document_verifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.document_verifications_id_seq', 1, false);


--
-- Name: documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.documents_id_seq', 1, false);


--
-- Name: email_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.email_logs_id_seq', 1, false);


--
-- Name: exporter_applications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.exporter_applications_id_seq', 1, false);


--
-- Name: forex_allocations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.forex_allocations_id_seq', 1, false);


--
-- Name: lab_test_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.lab_test_results_id_seq', 1, false);


--
-- Name: letters_of_credit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.letters_of_credit_id_seq', 1, false);


--
-- Name: notification_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.notification_templates_id_seq', 8, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: payment_confirmations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.payment_confirmations_id_seq', 1, false);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.payments_id_seq', 1, false);


--
-- Name: post_delivery_checklist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.post_delivery_checklist_id_seq', 1, false);


--
-- Name: post_delivery_issues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.post_delivery_issues_id_seq', 1, false);


--
-- Name: post_delivery_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.post_delivery_notifications_id_seq', 1, false);


--
-- Name: post_delivery_tracking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.post_delivery_tracking_id_seq', 1, false);


--
-- Name: quality_certificates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.quality_certificates_id_seq', 1, false);


--
-- Name: quality_inspections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.quality_inspections_id_seq', 1, false);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.roles_id_seq', 1, false);


--
-- Name: shipment_locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.shipment_locations_id_seq', 1, false);


--
-- Name: shipment_status_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.shipment_status_history_id_seq', 1, false);


--
-- Name: shipments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.shipments_id_seq', 1, false);


--
-- Name: sms_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.sms_logs_id_seq', 1, false);


--
-- Name: sync_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.sync_status_id_seq', 151656, true);


--
-- Name: system_alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.system_alerts_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.users_id_seq', 6, true);


--
-- Name: webhook_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.webhook_logs_id_seq', 1, false);


--
-- Name: webhooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: cecbs
--

SELECT pg_catalog.setval('public.webhooks_id_seq', 1, false);


--
-- Name: _schema_migrations _schema_migrations_migration_name_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public._schema_migrations
    ADD CONSTRAINT _schema_migrations_migration_name_key UNIQUE (migration_name);


--
-- Name: _schema_migrations _schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public._schema_migrations
    ADD CONSTRAINT _schema_migrations_pkey PRIMARY KEY (id);


--
-- Name: approval_requirements approval_requirements_document_type_entity_type_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.approval_requirements
    ADD CONSTRAINT approval_requirements_document_type_entity_type_key UNIQUE (document_type, entity_type);


--
-- Name: approval_requirements approval_requirements_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.approval_requirements
    ADD CONSTRAINT approval_requirements_pkey PRIMARY KEY (id);


--
-- Name: approval_workflow_state approval_workflow_state_document_id_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.approval_workflow_state
    ADD CONSTRAINT approval_workflow_state_document_id_key UNIQUE (document_id);


--
-- Name: approval_workflow_state approval_workflow_state_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.approval_workflow_state
    ADD CONSTRAINT approval_workflow_state_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: audit_trail audit_trail_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.audit_trail
    ADD CONSTRAINT audit_trail_pkey PRIMARY KEY (id);


--
-- Name: blockchain_contracts blockchain_contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.blockchain_contracts
    ADD CONSTRAINT blockchain_contracts_pkey PRIMARY KEY (contract_id);


--
-- Name: blockchain_customs blockchain_customs_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.blockchain_customs
    ADD CONSTRAINT blockchain_customs_pkey PRIMARY KEY (clearance_id);


--
-- Name: blockchain_documents blockchain_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.blockchain_documents
    ADD CONSTRAINT blockchain_documents_pkey PRIMARY KEY (document_id);


--
-- Name: blockchain_payments blockchain_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.blockchain_payments
    ADD CONSTRAINT blockchain_payments_pkey PRIMARY KEY (payment_id);


--
-- Name: blockchain_shipments blockchain_shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.blockchain_shipments
    ADD CONSTRAINT blockchain_shipments_pkey PRIMARY KEY (shipment_id);


--
-- Name: border_crossings border_crossings_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.border_crossings
    ADD CONSTRAINT border_crossings_pkey PRIMARY KEY (crossing_id);


--
-- Name: contracts contracts_contract_id_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_contract_id_key UNIQUE (contract_id);


--
-- Name: contracts contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_pkey PRIMARY KEY (id);


--
-- Name: customs_clearances customs_clearances_clearance_id_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.customs_clearances
    ADD CONSTRAINT customs_clearances_clearance_id_key UNIQUE (clearance_id);


--
-- Name: customs_clearances customs_clearances_clearance_number_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.customs_clearances
    ADD CONSTRAINT customs_clearances_clearance_number_key UNIQUE (clearance_number);


--
-- Name: customs_clearances customs_clearances_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.customs_clearances
    ADD CONSTRAINT customs_clearances_pkey PRIMARY KEY (id);


--
-- Name: customs_declarations customs_declarations_declaration_id_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.customs_declarations
    ADD CONSTRAINT customs_declarations_declaration_id_key UNIQUE (declaration_id);


--
-- Name: customs_declarations customs_declarations_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.customs_declarations
    ADD CONSTRAINT customs_declarations_pkey PRIMARY KEY (id);


--
-- Name: customs_inspections customs_inspections_inspection_id_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.customs_inspections
    ADD CONSTRAINT customs_inspections_inspection_id_key UNIQUE (inspection_id);


--
-- Name: customs_inspections customs_inspections_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.customs_inspections
    ADD CONSTRAINT customs_inspections_pkey PRIMARY KEY (id);


--
-- Name: customs_risk_assessments customs_risk_assessments_assessment_id_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.customs_risk_assessments
    ADD CONSTRAINT customs_risk_assessments_assessment_id_key UNIQUE (assessment_id);


--
-- Name: customs_risk_assessments customs_risk_assessments_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.customs_risk_assessments
    ADD CONSTRAINT customs_risk_assessments_pkey PRIMARY KEY (id);


--
-- Name: document_signatures document_signatures_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.document_signatures
    ADD CONSTRAINT document_signatures_pkey PRIMARY KEY (id);


--
-- Name: document_verifications document_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.document_verifications
    ADD CONSTRAINT document_verifications_pkey PRIMARY KEY (id);


--
-- Name: document_verifications document_verifications_verification_id_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.document_verifications
    ADD CONSTRAINT document_verifications_verification_id_key UNIQUE (verification_id);


--
-- Name: documents documents_document_id_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_document_id_key UNIQUE (document_id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: email_logs email_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_pkey PRIMARY KEY (id);


--
-- Name: export_proceeds_repatriation export_proceeds_repatriation_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.export_proceeds_repatriation
    ADD CONSTRAINT export_proceeds_repatriation_pkey PRIMARY KEY (repatriation_id);


--
-- Name: exporter_applications exporter_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.exporter_applications
    ADD CONSTRAINT exporter_applications_pkey PRIMARY KEY (id);


--
-- Name: forex_allocations forex_allocations_allocation_id_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.forex_allocations
    ADD CONSTRAINT forex_allocations_allocation_id_key UNIQUE (allocation_id);


--
-- Name: forex_allocations forex_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.forex_allocations
    ADD CONSTRAINT forex_allocations_pkey PRIMARY KEY (id);


--
-- Name: lab_test_results lab_test_results_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.lab_test_results
    ADD CONSTRAINT lab_test_results_pkey PRIMARY KEY (id);


--
-- Name: lab_test_results lab_test_results_test_id_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.lab_test_results
    ADD CONSTRAINT lab_test_results_test_id_key UNIQUE (test_id);


--
-- Name: lc_discrepancies lc_discrepancies_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.lc_discrepancies
    ADD CONSTRAINT lc_discrepancies_pkey PRIMARY KEY (discrepancy_id);


--
-- Name: letters_of_credit letters_of_credit_lc_number_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.letters_of_credit
    ADD CONSTRAINT letters_of_credit_lc_number_key UNIQUE (lc_number);


--
-- Name: letters_of_credit letters_of_credit_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.letters_of_credit
    ADD CONSTRAINT letters_of_credit_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (user_id);


--
-- Name: notification_templates notification_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_pkey PRIMARY KEY (id);


--
-- Name: notification_templates notification_templates_template_code_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_template_code_key UNIQUE (template_code);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: payment_confirmations payment_confirmations_confirmation_id_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.payment_confirmations
    ADD CONSTRAINT payment_confirmations_confirmation_id_key UNIQUE (confirmation_id);


--
-- Name: payment_confirmations payment_confirmations_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.payment_confirmations
    ADD CONSTRAINT payment_confirmations_pkey PRIMARY KEY (id);


--
-- Name: payments payments_payment_id_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_payment_id_key UNIQUE (payment_id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: post_delivery_checklist post_delivery_checklist_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.post_delivery_checklist
    ADD CONSTRAINT post_delivery_checklist_pkey PRIMARY KEY (id);


--
-- Name: post_delivery_issues post_delivery_issues_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.post_delivery_issues
    ADD CONSTRAINT post_delivery_issues_pkey PRIMARY KEY (id);


--
-- Name: post_delivery_notifications post_delivery_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.post_delivery_notifications
    ADD CONSTRAINT post_delivery_notifications_pkey PRIMARY KEY (id);


--
-- Name: post_delivery_tracking post_delivery_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.post_delivery_tracking
    ADD CONSTRAINT post_delivery_tracking_pkey PRIMARY KEY (id);


--
-- Name: post_delivery_tracking post_delivery_tracking_tracking_id_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.post_delivery_tracking
    ADD CONSTRAINT post_delivery_tracking_tracking_id_key UNIQUE (tracking_id);


--
-- Name: pre_shipment_inspections pre_shipment_inspections_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.pre_shipment_inspections
    ADD CONSTRAINT pre_shipment_inspections_pkey PRIMARY KEY (inspection_id);


--
-- Name: quality_certificates quality_certificates_certificate_number_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.quality_certificates
    ADD CONSTRAINT quality_certificates_certificate_number_key UNIQUE (certificate_number);


--
-- Name: quality_certificates quality_certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.quality_certificates
    ADD CONSTRAINT quality_certificates_pkey PRIMARY KEY (id);


--
-- Name: quality_inspections quality_inspections_inspection_id_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.quality_inspections
    ADD CONSTRAINT quality_inspections_inspection_id_key UNIQUE (inspection_id);


--
-- Name: quality_inspections quality_inspections_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.quality_inspections
    ADD CONSTRAINT quality_inspections_pkey PRIMARY KEY (id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: shipment_locations shipment_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.shipment_locations
    ADD CONSTRAINT shipment_locations_pkey PRIMARY KEY (id);


--
-- Name: shipment_status_history shipment_status_history_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.shipment_status_history
    ADD CONSTRAINT shipment_status_history_pkey PRIMARY KEY (id);


--
-- Name: shipments shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_pkey PRIMARY KEY (id);


--
-- Name: shipments shipments_shipment_id_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_shipment_id_key UNIQUE (shipment_id);


--
-- Name: sms_logs sms_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.sms_logs
    ADD CONSTRAINT sms_logs_pkey PRIMARY KEY (id);


--
-- Name: sync_status sync_status_couch_instance_database_name_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.sync_status
    ADD CONSTRAINT sync_status_couch_instance_database_name_key UNIQUE (couch_instance, database_name);


--
-- Name: sync_status sync_status_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.sync_status
    ADD CONSTRAINT sync_status_pkey PRIMARY KEY (id);


--
-- Name: system_alerts system_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.system_alerts
    ADD CONSTRAINT system_alerts_pkey PRIMARY KEY (id);


--
-- Name: post_delivery_issues unique_active_issue; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.post_delivery_issues
    ADD CONSTRAINT unique_active_issue UNIQUE (shipment_id, issue_type);


--
-- Name: post_delivery_checklist unique_checklist_item; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.post_delivery_checklist
    ADD CONSTRAINT unique_checklist_item UNIQUE (shipment_id, item_type);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: webhook_logs webhook_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.webhook_logs
    ADD CONSTRAINT webhook_logs_pkey PRIMARY KEY (id);


--
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (id);


--
-- Name: webhooks webhooks_webhook_id_key; Type: CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_webhook_id_key UNIQUE (webhook_id);


--
-- Name: idx_alerts_resolved; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_alerts_resolved ON public.system_alerts USING btree (resolved);


--
-- Name: idx_alerts_severity; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_alerts_severity ON public.system_alerts USING btree (severity);


--
-- Name: idx_alerts_type; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_alerts_type ON public.system_alerts USING btree (alert_type);


--
-- Name: idx_approval_requirements_type; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_approval_requirements_type ON public.approval_requirements USING btree (document_type, entity_type, active);


--
-- Name: idx_approval_workflow_document; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_approval_workflow_document ON public.approval_workflow_state USING btree (document_id, approval_status);


--
-- Name: idx_approval_workflow_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_approval_workflow_status ON public.approval_workflow_state USING btree (approval_status);


--
-- Name: idx_audit_log_action; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_audit_log_action ON public.audit_log USING btree (action);


--
-- Name: idx_audit_log_created_at; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_audit_log_created_at ON public.audit_log USING btree (created_at DESC);


--
-- Name: idx_audit_log_details; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_audit_log_details ON public.audit_log USING gin (details);


--
-- Name: idx_audit_log_entity; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_audit_log_entity ON public.audit_log USING btree (entity_type, entity_id);


--
-- Name: idx_audit_log_user_id; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_audit_log_user_id ON public.audit_log USING btree (user_id);


--
-- Name: idx_audit_logs_blockchain_tx; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_audit_logs_blockchain_tx ON public.audit_logs USING btree (blockchain_tx_id);


--
-- Name: idx_audit_logs_category; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_audit_logs_category ON public.audit_logs USING btree (event_category);


--
-- Name: idx_audit_logs_event_type; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_audit_logs_event_type ON public.audit_logs USING btree (event_type);


--
-- Name: idx_audit_logs_metadata; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_audit_logs_metadata ON public.audit_logs USING gin (metadata);


--
-- Name: idx_audit_logs_resource; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_audit_logs_resource ON public.audit_logs USING btree (resource_type, resource_id);


--
-- Name: idx_audit_logs_severity; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_audit_logs_severity ON public.audit_logs USING btree (severity);


--
-- Name: idx_audit_logs_tags; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_audit_logs_tags ON public.audit_logs USING gin (tags);


--
-- Name: idx_audit_logs_timestamp_desc; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_audit_logs_timestamp_desc ON public.audit_logs USING btree ("timestamp" DESC);


--
-- Name: idx_audit_logs_user_id; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: idx_audit_trail_action; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_audit_trail_action ON public.audit_trail USING btree (action);


--
-- Name: idx_audit_trail_entity; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_audit_trail_entity ON public.audit_trail USING btree (entity_type, entity_id);


--
-- Name: idx_audit_trail_entity_action; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_audit_trail_entity_action ON public.audit_trail USING btree (entity_type, action);


--
-- Name: idx_audit_trail_performed_by; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_audit_trail_performed_by ON public.audit_trail USING btree (performed_by);


--
-- Name: idx_audit_trail_performed_by_org; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_audit_trail_performed_by_org ON public.audit_trail USING btree (performed_by_org);


--
-- Name: idx_audit_trail_timestamp; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_audit_trail_timestamp ON public.audit_trail USING btree ("timestamp" DESC);


--
-- Name: idx_audit_trail_timestamp_desc; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_audit_trail_timestamp_desc ON public.audit_trail USING btree ("timestamp" DESC);


--
-- Name: idx_audit_trail_user; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_audit_trail_user ON public.audit_trail USING btree (user_id);


--
-- Name: idx_blockchain_contracts_buyer; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_blockchain_contracts_buyer ON public.blockchain_contracts USING btree (buyer_id);


--
-- Name: idx_blockchain_contracts_exporter; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_blockchain_contracts_exporter ON public.blockchain_contracts USING btree (exporter_id);


--
-- Name: idx_blockchain_contracts_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_blockchain_contracts_status ON public.blockchain_contracts USING btree (status);


--
-- Name: idx_blockchain_customs_declaration; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_blockchain_customs_declaration ON public.blockchain_customs USING btree (declaration_number);


--
-- Name: idx_blockchain_customs_shipment; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_blockchain_customs_shipment ON public.blockchain_customs USING btree (shipment_id);


--
-- Name: idx_blockchain_customs_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_blockchain_customs_status ON public.blockchain_customs USING btree (clearance_status);


--
-- Name: idx_blockchain_documents_issuer; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_blockchain_documents_issuer ON public.blockchain_documents USING btree (issuer);


--
-- Name: idx_blockchain_documents_shipment; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_blockchain_documents_shipment ON public.blockchain_documents USING btree (shipment_id);


--
-- Name: idx_blockchain_documents_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_blockchain_documents_status ON public.blockchain_documents USING btree (status);


--
-- Name: idx_blockchain_documents_type; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_blockchain_documents_type ON public.blockchain_documents USING btree (document_type);


--
-- Name: idx_blockchain_payments_lc; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_blockchain_payments_lc ON public.blockchain_payments USING btree (lc_number);


--
-- Name: idx_blockchain_payments_shipment; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_blockchain_payments_shipment ON public.blockchain_payments USING btree (shipment_id);


--
-- Name: idx_blockchain_payments_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_blockchain_payments_status ON public.blockchain_payments USING btree (status);


--
-- Name: idx_blockchain_shipments_buyer; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_blockchain_shipments_buyer ON public.blockchain_shipments USING btree (buyer_id);


--
-- Name: idx_blockchain_shipments_contract; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_blockchain_shipments_contract ON public.blockchain_shipments USING btree (contract_id);


--
-- Name: idx_blockchain_shipments_exporter; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_blockchain_shipments_exporter ON public.blockchain_shipments USING btree (exporter_id);


--
-- Name: idx_blockchain_shipments_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_blockchain_shipments_status ON public.blockchain_shipments USING btree (status);


--
-- Name: idx_blockchain_shipments_synced_at; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_blockchain_shipments_synced_at ON public.blockchain_shipments USING btree (synced_at DESC);


--
-- Name: idx_blockchain_shipments_synced_from; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_blockchain_shipments_synced_from ON public.blockchain_shipments USING btree (synced_from);


--
-- Name: idx_checklist_completed; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_checklist_completed ON public.post_delivery_checklist USING btree (completed);


--
-- Name: idx_checklist_shipment; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_checklist_shipment ON public.post_delivery_checklist USING btree (shipment_id);


--
-- Name: idx_clearances_exit_point; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_clearances_exit_point ON public.customs_clearances USING btree (exit_point);


--
-- Name: idx_clearances_shipment; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_clearances_shipment ON public.customs_clearances USING btree (shipment_id);


--
-- Name: idx_clearances_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_clearances_status ON public.customs_clearances USING btree (status);


--
-- Name: idx_contracts_buyer; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_contracts_buyer ON public.contracts USING btree (buyer_id);


--
-- Name: idx_contracts_exporter; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_contracts_exporter ON public.contracts USING btree (exporter_id);


--
-- Name: idx_contracts_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_contracts_status ON public.contracts USING btree (status);


--
-- Name: idx_crossing_arrival; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_crossing_arrival ON public.border_crossings USING btree (arrival_date);


--
-- Name: idx_crossing_border_post; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_crossing_border_post ON public.border_crossings USING btree (border_post);


--
-- Name: idx_crossing_compliance; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_crossing_compliance ON public.border_crossings USING btree (compliance_status);


--
-- Name: idx_crossing_contract; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_crossing_contract ON public.border_crossings USING btree (contract_id);


--
-- Name: idx_crossing_departure; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_crossing_departure ON public.border_crossings USING btree (departure_date);


--
-- Name: idx_crossing_exporter; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_crossing_exporter ON public.border_crossings USING btree (exporter_id);


--
-- Name: idx_crossing_shipment; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_crossing_shipment ON public.border_crossings USING btree (shipment_id);


--
-- Name: idx_crossing_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_crossing_status ON public.border_crossings USING btree (status);


--
-- Name: idx_customs_clear_shipment; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_customs_clear_shipment ON public.customs_clearances USING btree (shipment_id);


--
-- Name: idx_customs_decl_shipment; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_customs_decl_shipment ON public.customs_declarations USING btree (shipment_id);


--
-- Name: idx_customs_declarations_exporter_id; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_customs_declarations_exporter_id ON public.customs_declarations USING btree (exporter_id);


--
-- Name: idx_customs_declarations_shipment_id; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_customs_declarations_shipment_id ON public.customs_declarations USING btree (shipment_id);


--
-- Name: idx_customs_declarations_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_customs_declarations_status ON public.customs_declarations USING btree (status);


--
-- Name: idx_discrepancy_lc; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_discrepancy_lc ON public.lc_discrepancies USING btree (lc_id);


--
-- Name: idx_discrepancy_reported_date; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_discrepancy_reported_date ON public.lc_discrepancies USING btree (reported_date);


--
-- Name: idx_discrepancy_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_discrepancy_status ON public.lc_discrepancies USING btree (status);


--
-- Name: idx_doc_signatures_approval; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_doc_signatures_approval ON public.document_signatures USING btree (document_id, signature_type, approval_status);


--
-- Name: idx_doc_verifications_document; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_doc_verifications_document ON public.document_verifications USING btree (document_id);


--
-- Name: idx_documents_contract; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_documents_contract ON public.documents USING btree (contract_id);


--
-- Name: idx_documents_exporter; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_documents_exporter ON public.documents USING btree (exporter_id);


--
-- Name: idx_documents_file_path; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_documents_file_path ON public.documents USING btree (file_path);


--
-- Name: idx_documents_shipment; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_documents_shipment ON public.documents USING btree (shipment_id);


--
-- Name: idx_documents_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_documents_status ON public.documents USING btree (status);


--
-- Name: idx_documents_type; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_documents_type ON public.documents USING btree (document_type);


--
-- Name: idx_email_logs_recipient; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_email_logs_recipient ON public.email_logs USING btree (recipient);


--
-- Name: idx_email_logs_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_email_logs_status ON public.email_logs USING btree (status);


--
-- Name: idx_exporter_applications_license_number; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_exporter_applications_license_number ON public.exporter_applications USING btree (license_number);


--
-- Name: idx_exporter_applications_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_exporter_applications_status ON public.exporter_applications USING btree (status);


--
-- Name: idx_exporter_applications_submitted_date; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_exporter_applications_submitted_date ON public.exporter_applications USING btree (submitted_date);


--
-- Name: idx_exporter_applications_temp_username; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_exporter_applications_temp_username ON public.exporter_applications USING btree (temp_username);


--
-- Name: idx_forex_allocations_confirmed_at; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_forex_allocations_confirmed_at ON public.forex_allocations USING btree (confirmed_at);


--
-- Name: idx_forex_allocations_contract; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_forex_allocations_contract ON public.forex_allocations USING btree (contract_id);


--
-- Name: idx_forex_allocations_exporter; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_forex_allocations_exporter ON public.forex_allocations USING btree (exporter_id);


--
-- Name: idx_forex_allocations_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_forex_allocations_status ON public.forex_allocations USING btree (status);


--
-- Name: idx_forex_lc; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_forex_lc ON public.forex_allocations USING btree (lc_number);


--
-- Name: idx_forex_shipment; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_forex_shipment ON public.forex_allocations USING btree (shipment_id);


--
-- Name: idx_inspection_agency; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_inspection_agency ON public.pre_shipment_inspections USING btree (inspection_agency);


--
-- Name: idx_inspection_contract; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_inspection_contract ON public.pre_shipment_inspections USING btree (contract_id);


--
-- Name: idx_inspection_date; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_inspection_date ON public.pre_shipment_inspections USING btree (inspection_date);


--
-- Name: idx_inspection_exporter; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_inspection_exporter ON public.pre_shipment_inspections USING btree (exporter_id);


--
-- Name: idx_inspection_result; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_inspection_result ON public.pre_shipment_inspections USING btree (overall_result);


--
-- Name: idx_inspection_shipment; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_inspection_shipment ON public.pre_shipment_inspections USING btree (shipment_id);


--
-- Name: idx_inspection_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_inspection_status ON public.pre_shipment_inspections USING btree (status);


--
-- Name: idx_inspections_shipment; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_inspections_shipment ON public.customs_inspections USING btree (shipment_id);


--
-- Name: idx_issues_resolved; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_issues_resolved ON public.post_delivery_issues USING btree (resolved);


--
-- Name: idx_issues_severity; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_issues_severity ON public.post_delivery_issues USING btree (severity);


--
-- Name: idx_issues_shipment; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_issues_shipment ON public.post_delivery_issues USING btree (shipment_id);


--
-- Name: idx_issues_type; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_issues_type ON public.post_delivery_issues USING btree (issue_type);


--
-- Name: idx_lc_approved_by_msp; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_lc_approved_by_msp ON public.letters_of_credit USING btree (approved_by_msp);


--
-- Name: idx_lc_issued_by_msp; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_lc_issued_by_msp ON public.letters_of_credit USING btree (issued_by_msp);


--
-- Name: idx_lc_shipment; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_lc_shipment ON public.letters_of_credit USING btree (shipment_id);


--
-- Name: idx_lc_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_lc_status ON public.letters_of_credit USING btree (status);


--
-- Name: idx_locations_recorded; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_locations_recorded ON public.shipment_locations USING btree (recorded_at);


--
-- Name: idx_locations_shipment; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_locations_shipment ON public.shipment_locations USING btree (shipment_id);


--
-- Name: idx_notification_templates_active; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_notification_templates_active ON public.notification_templates USING btree (is_active);


--
-- Name: idx_notification_templates_code; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_notification_templates_code ON public.notification_templates USING btree (template_code);


--
-- Name: idx_notifications_created_at; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_notifications_created_at ON public.notifications USING btree (created_at DESC);


--
-- Name: idx_notifications_priority; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_notifications_priority ON public.notifications USING btree (priority);


--
-- Name: idx_notifications_read; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_notifications_read ON public.post_delivery_notifications USING btree (read);


--
-- Name: idx_notifications_recipient; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_notifications_recipient ON public.post_delivery_notifications USING btree (recipient_role);


--
-- Name: idx_notifications_resource; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_notifications_resource ON public.notifications USING btree (resource_type, resource_id);


--
-- Name: idx_notifications_sent; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_notifications_sent ON public.post_delivery_notifications USING btree (sent);


--
-- Name: idx_notifications_shipment; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_notifications_shipment ON public.post_delivery_notifications USING btree (shipment_id);


--
-- Name: idx_notifications_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_notifications_status ON public.notifications USING btree (status);


--
-- Name: idx_notifications_type; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_notifications_type ON public.notifications USING btree (notification_type);


--
-- Name: idx_notifications_user_id; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: idx_payment_confirmations_payment; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_payment_confirmations_payment ON public.payment_confirmations USING btree (payment_id);


--
-- Name: idx_payments_contract; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_payments_contract ON public.payments USING btree (contract_id);


--
-- Name: idx_payments_exporter; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_payments_exporter ON public.payments USING btree (exporter_id);


--
-- Name: idx_payments_lc; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_payments_lc ON public.payments USING btree (lc_number);


--
-- Name: idx_payments_shipment; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_payments_shipment ON public.payments USING btree (shipment_id);


--
-- Name: idx_post_delivery_contract; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_post_delivery_contract ON public.post_delivery_tracking USING btree (contract_id);


--
-- Name: idx_post_delivery_delivery_date; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_post_delivery_delivery_date ON public.post_delivery_tracking USING btree (delivery_date);


--
-- Name: idx_post_delivery_exporter; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_post_delivery_exporter ON public.post_delivery_tracking USING btree (exporter_id);


--
-- Name: idx_post_delivery_shipment; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_post_delivery_shipment ON public.post_delivery_tracking USING btree (shipment_id);


--
-- Name: idx_post_delivery_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_post_delivery_status ON public.post_delivery_tracking USING btree (overall_status);


--
-- Name: idx_quality_certificates_exporter; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_quality_certificates_exporter ON public.quality_certificates USING btree (exporter_id);


--
-- Name: idx_quality_inspections_exporter; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_quality_inspections_exporter ON public.quality_inspections USING btree (exporter_id);


--
-- Name: idx_quality_inspections_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_quality_inspections_status ON public.quality_inspections USING btree (status);


--
-- Name: idx_repatriation_contract; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_repatriation_contract ON public.export_proceeds_repatriation USING btree (contract_id);


--
-- Name: idx_repatriation_deadline; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_repatriation_deadline ON public.export_proceeds_repatriation USING btree (compliance_deadline);


--
-- Name: idx_repatriation_exporter; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_repatriation_exporter ON public.export_proceeds_repatriation USING btree (exporter_id);


--
-- Name: idx_repatriation_overdue; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_repatriation_overdue ON public.export_proceeds_repatriation USING btree (is_overdue) WHERE (is_overdue = true);


--
-- Name: idx_repatriation_payment; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_repatriation_payment ON public.export_proceeds_repatriation USING btree (payment_id);


--
-- Name: idx_repatriation_shipment; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_repatriation_shipment ON public.export_proceeds_repatriation USING btree (shipment_id);


--
-- Name: idx_repatriation_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_repatriation_status ON public.export_proceeds_repatriation USING btree (status);


--
-- Name: idx_risk_assessments_shipment; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_risk_assessments_shipment ON public.customs_risk_assessments USING btree (shipment_id);


--
-- Name: idx_shipments_created; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_shipments_created ON public.shipments USING btree (created_at DESC);


--
-- Name: idx_shipments_exporter; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_shipments_exporter ON public.shipments USING btree (exporter_id);


--
-- Name: idx_shipments_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_shipments_status ON public.shipments USING btree (status);


--
-- Name: idx_sms_logs_phone; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_sms_logs_phone ON public.sms_logs USING btree (phone);


--
-- Name: idx_sms_logs_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_sms_logs_status ON public.sms_logs USING btree (status);


--
-- Name: idx_status_history_date; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_status_history_date ON public.shipment_status_history USING btree (update_date);


--
-- Name: idx_status_history_shipment; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_status_history_shipment ON public.shipment_status_history USING btree (shipment_id);


--
-- Name: idx_sync_status_instance; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_sync_status_instance ON public.sync_status USING btree (couch_instance);


--
-- Name: idx_sync_status_last_sync; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_sync_status_last_sync ON public.sync_status USING btree (last_sync DESC);


--
-- Name: idx_sync_status_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_sync_status_status ON public.sync_status USING btree (status);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_exporter_id; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_users_exporter_id ON public.users USING btree (exporter_id);


--
-- Name: idx_users_organization; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_users_organization ON public.users USING btree (organization);


--
-- Name: idx_users_role; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_users_role ON public.users USING btree (role);


--
-- Name: idx_users_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_users_status ON public.users USING btree (status);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: idx_webhook_logs_event; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_webhook_logs_event ON public.webhook_logs USING btree (event);


--
-- Name: idx_webhook_logs_status; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_webhook_logs_status ON public.webhook_logs USING btree (status);


--
-- Name: idx_webhook_logs_webhook; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_webhook_logs_webhook ON public.webhook_logs USING btree (webhook_id);


--
-- Name: idx_webhooks_active; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_webhooks_active ON public.webhooks USING btree (active);


--
-- Name: idx_webhooks_org; Type: INDEX; Schema: public; Owner: cecbs
--

CREATE INDEX idx_webhooks_org ON public.webhooks USING btree (organization);


--
-- Name: post_delivery_tracking trg_auto_resolve_issues; Type: TRIGGER; Schema: public; Owner: cecbs
--

CREATE TRIGGER trg_auto_resolve_issues AFTER UPDATE ON public.post_delivery_tracking FOR EACH ROW EXECUTE FUNCTION public.auto_resolve_issues();


--
-- Name: post_delivery_tracking trg_update_completion; Type: TRIGGER; Schema: public; Owner: cecbs
--

CREATE TRIGGER trg_update_completion BEFORE UPDATE ON public.post_delivery_tracking FOR EACH ROW EXECUTE FUNCTION public.update_post_delivery_completion();


--
-- Name: lc_discrepancies trigger_lc_discrepancy_updated_at; Type: TRIGGER; Schema: public; Owner: cecbs
--

CREATE TRIGGER trigger_lc_discrepancy_updated_at BEFORE UPDATE ON public.lc_discrepancies FOR EACH ROW EXECUTE FUNCTION public.update_lc_discrepancy_timestamp();


--
-- Name: document_signatures trigger_update_approval_workflow; Type: TRIGGER; Schema: public; Owner: cecbs
--

CREATE TRIGGER trigger_update_approval_workflow AFTER INSERT ON public.document_signatures FOR EACH ROW EXECUTE FUNCTION public.update_approval_workflow();


--
-- Name: document_verifications document_verifications_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: cecbs
--

ALTER TABLE ONLY public.document_verifications
    ADD CONSTRAINT document_verifications_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(document_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict YmSEDghiqxaZTntYMF1d9GsRskgEBOY9MMHhPjQbQdYQIDhXgaxwcQnznbVJ7zx

